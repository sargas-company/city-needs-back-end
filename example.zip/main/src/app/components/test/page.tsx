import ReactLenis from "lenis/react";

export default function TestPage() {

    return (
        <ReactLenis root>
            <section className="min-h-screen py-[var(--width-10)]"></section>
        </ReactLenis>
    );
}
