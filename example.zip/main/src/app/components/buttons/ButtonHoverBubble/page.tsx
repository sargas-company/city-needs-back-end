"use client";

import ButtonHoverBubble from "@/components/button/ButtonHoverBubble";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function ButtonHoverBubblePage() {
    return (
        <ThemeProvider
            defaultButtonVariant="hover-bubble"
            defaultTextAnimation="entrance-slide"
            borderRadius="rounded"
            contentWidth="medium"
            sizing="medium"
            background="aurora"
            cardStyle="glass-elevated"
            primaryButtonStyle="flat"
            secondaryButtonStyle="minimal"
        >
            <section className="h-screen flex items-center justify-center">
                <ButtonHoverBubble text="Contact Us" />
            </section>
        </ThemeProvider>
    );
}
