"use client";

import ButtonTextUnderline from "@/components/button/ButtonTextUnderline";

export default function ButtonTextUnderlinePage() {
    return (
        <section className="h-screen flex items-center justify-center">
            <ButtonTextUnderline text="Learn More" />
        </section>
    );
}