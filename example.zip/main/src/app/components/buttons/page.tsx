import ReactLenis from "lenis/react";
import Link from "next/link";

export default function ButtonsPage() {
    const buttonComponents = [
        {
            title: "Hover Magnetic",
            href: "/components/buttons/ButtonHoverMagnetic",
        },
        {
            title: "Hover Bubble",
            href: "/components/buttons/ButtonHoverBubble",
        },
        {
            title: "Expand Hover",
            href: "/components/buttons/ButtonExpandHover",
        },
        {
            title: "Shift Hover",
            href: "/components/buttons/ButtonShiftHover",
        },
        {
            title: "Text Stagger",
            href: "/components/buttons/ButtonTextStagger",
        },
        {
            title: "Icon Arrow",
            href: "/components/buttons/ButtonIconArrow",
        },
        {
            title: "Text Underline",
            href: "/components/buttons/ButtonTextUnderline",
        },
    ];

    return (
        <ReactLenis root>
            <section className="min-h-screen py-[var(--width-10)]">
                <div className="w-full px-[var(--width-10)]">
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                        {buttonComponents.map((component) => (
                            <Link key={component.href} href={component.href}>
                                <div className="aspect-square tag-card relative rounded p-6 flex justify-center items-center text-center cursor-pointer">
                                    <h3 className="text-xl font-normal text-black">{component.title}</h3>
                                </div>
                            </Link>
                        ))}
                    </div>
                </div>
            </section>
        </ReactLenis>
    );
}