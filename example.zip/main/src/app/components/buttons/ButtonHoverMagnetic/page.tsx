"use client";

import ButtonHoverMagnetic from "@/components/button/ButtonHoverMagnetic/ButtonHoverMagnetic";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function ButtonHoverMagneticPage() {
    return (
        <ThemeProvider
            defaultButtonVariant="hover-magnetic"
            defaultTextAnimation="entrance-slide"
            borderRadius="rounded"
            contentWidth="medium"
            sizing="medium"
            background="aurora"
            cardStyle="glass-elevated"
            primaryButtonStyle="gradient"
            secondaryButtonStyle="glass"
        >
            <section className="h-screen flex items-center justify-center">
                <ButtonHoverMagnetic text="Magnetic Button" />
            </section>
        </ThemeProvider>
    );
}