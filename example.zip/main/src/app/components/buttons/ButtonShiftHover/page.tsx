"use client";

import ButtonShiftHover from "@/components/button/ButtonShiftHover/ButtonShiftHover";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function ButtonShiftHoverPage() {
    return (
        <ThemeProvider
            defaultButtonVariant="shift-hover"
            defaultTextAnimation="entrance-slide"
            borderRadius="rounded"
            contentWidth="medium"
            sizing="medium"
            background="aurora"
            cardStyle="glass-elevated"
            primaryButtonStyle="gradient"
            secondaryButtonStyle="glass"
        >
            <section className="h-screen flex items-center justify-center">
                <ButtonShiftHover text="Get Started" />
            </section>
        </ThemeProvider>
    );
}