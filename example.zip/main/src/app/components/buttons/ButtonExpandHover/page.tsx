"use client";

import ButtonExpandHover from "@/components/button/ButtonExpandHover";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function ButtonExpandHoverPage() {
    return (
        <ThemeProvider
            defaultButtonVariant="expand-hover"
            defaultTextAnimation="entrance-slide"
            borderRadius="rounded"
            contentWidth="medium"
            sizing="medium"
            background="aurora"
            cardStyle="glass-elevated"
            primaryButtonStyle="gradient"
            secondaryButtonStyle="layered"
        >
            <section className="h-screen flex items-center justify-center">
                <ButtonExpandHover text="Get Started" />
            </section>
        </ThemeProvider>
    );
}
