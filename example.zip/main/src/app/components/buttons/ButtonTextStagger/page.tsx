"use client";

import ButtonTextStagger from "@/components/button/ButtonTextStagger/ButtonTextStagger";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function ButtonTextStaggerPage() {
    return (
        <ThemeProvider
            defaultButtonVariant="text-stagger"
            defaultTextAnimation="entrance-slide"
            borderRadius="rounded"
            contentWidth="medium"
            sizing="medium"
            background="aurora"
            cardStyle="glass-elevated"
            primaryButtonStyle="gradient"
            secondaryButtonStyle="glass"
        >
            <section className="h-screen flex items-center justify-center">
                <ButtonTextStagger text="Explore More" />
            </section>
        </ThemeProvider>
    );
}