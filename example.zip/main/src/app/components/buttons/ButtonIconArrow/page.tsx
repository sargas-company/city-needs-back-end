"use client";

import ButtonIconArrow from "@/components/button/ButtonIconArrow";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function ButtonIconArrowPage() {
    return (
        <ThemeProvider
            defaultButtonVariant="icon-arrow"
            defaultTextAnimation="entrance-slide"
            borderRadius="rounded"
            contentWidth="medium"
            sizing="medium"
            background="aurora"
            cardStyle="glass-elevated"
            primaryButtonStyle="gradient"
            secondaryButtonStyle="glass"
        >
            <section className="h-screen flex items-center justify-center">
                <ButtonIconArrow text="Continue" />
            </section>
        </ThemeProvider>
    );
}