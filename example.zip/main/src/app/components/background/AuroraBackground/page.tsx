"use client";

import AuroraBackground from "@/components/background/AuroraBackground";

export default function AuroraBackgroundPage() {
    return (
        <section className="h-screen flex items-center justify-center">
            <AuroraBackground />
        </section>
    );
}
