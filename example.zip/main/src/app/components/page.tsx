import ReactLenis from "lenis/react";
import Link from "next/link";

export default function ComponentsPage() {
    const categories = [
        {
            title: "Text",
            href: "/components/text",
        },
        {
            title: "Buttons",
            href: "/components/buttons",
        },
        {
            title: "Textbox",
            href: "/components/textbox",
        },
        {
            title: "Sections",
            href: "/components/sections",
        },
        {
            title: "Navbar",
            href: "/components/navbar",
        },
        {
            title: "Background",
            href: "/components/background",
        }
    ];

    return (
        <ReactLenis root>
            <section className="min-h-screen py-[var(--width-10)]">
                <div className="w-full px-[var(--width-10)]">
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                        {categories.map((category) => (
                            <Link key={category.href} href={category.href}>
                                <div className="aspect-square tag-card relative rounded p-6 flex justify-center items-center text-center cursor-pointer">
                                    <h3 className="text-xl font-normal text-black">{category.title}</h3>
                                </div>
                            </Link>
                        ))}
                    </div>
                </div>
            </section>
        </ReactLenis>
    );
}
