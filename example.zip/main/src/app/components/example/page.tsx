"use client";

import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import HeroSplit from "@/components/sections/hero/HeroSplit";
import SocialProofOne from "@/components/sections/socialProof/SocialProofOne";
import SplitAbout from "@/components/sections/about/SplitAbout";
import MetricCardOne from "@/components/sections/metrics/MetricCardOne";
import MetricCardTwo from "@/components/sections/metrics/MetricCardTwo";
import MetricCardThree from "@/components/sections/metrics/MetricCardThree";
import FeatureCardOne from "@/components/sections/feature/FeatureCardOne";
import FeatureCardTwo from "@/components/sections/feature/FeatureCardTwo";
import FeatureCardThree from "@/components/sections/feature/featureCardThree/FeatureCardThree";
import FeatureCardSeven from "@/components/sections/feature/FeatureCardSeven";
import ProductCardOne from "@/components/sections/product/ProductCardOne";
import ProductCardTwo from "@/components/sections/product/ProductCardTwo";
import ProductCardThree from "@/components/sections/product/ProductCardThree";
import PricingCardOne from "@/components/sections/pricing/PricingCardOne";
import PricingCardTwo from "@/components/sections/pricing/PricingCardTwo";
import PricingCardThree from "@/components/sections/pricing/PricingCardThree";
import TestimonialCardOne from "@/components/sections/testimonial/TestimonialCardOne";
import TestimonialCardTwo from "@/components/sections/testimonial/TestimonialCardTwo";
import TestimonialCardThree from "@/components/sections/testimonial/TestimonialCardThree";
import FaqBase from "@/components/sections/faq/FaqBase";
import BlogCardOne from "@/components/sections/blog/BlogCardOne";
import BlogCardTwo from "@/components/sections/blog/BlogCardTwo";
import TeamCardOne from "@/components/sections/team/TeamCardOne";
import TeamCardTwo from "@/components/sections/team/TeamCardTwo";
import TeamCardThree from "@/components/sections/team/TeamCardThree";
import ContactCenter from "@/components/sections/contact/ContactCenter";
import FooterBase from "@/components/sections/footer/FooterBase";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import type { NavItem } from "@/types/navigation";
import { Zap, Target, Users, TrendingUp, Package, Mail } from "lucide-react";

const navItems: NavItem[] = [
  { name: "Home", id: "home" },
  { name: "About", id: "about" },
  { name: "Features", id: "features" },
  { name: "Products", id: "products" },
  { name: "Pricing", id: "pricing" },
  { name: "Blog", id: "blog" },
  { name: "Contact", id: "contact" },
];

const footerColumns = [
  {
    title: "Product",
    items: [
      { label: "Features", href: "features" },
      { label: "Pricing", href: "pricing" },
      { label: "Team", href: "team" },
    ],
  },
  {
    title: "Company",
    items: [
      { label: "About", href: "about" },
      { label: "Blog", href: "https://webild.io/blog" },
      { label: "Careers", href: "https://webild.io/careers" },
    ],
  },
  {
    title: "Legal",
    items: [
      { label: "Privacy", href: "https://webild.io/privacy" },
      { label: "Terms", href: "https://webild.io/terms" },
    ],
  },
];

export default function ExamplePage() {
  return (
    <>
      <ThemeProvider defaultButtonVariant="hover-bubble" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="large" background="animatedGrid" cardStyle="spotlight" primaryButtonStyle="outline" secondaryButtonStyle="glass">
        <NavbarLayoutFloatingOverlay
          navItems={navItems}
          button={{ text: "Get Started", href: "https://webild.io" }}
        />

        <div id="home">
          <HeroSplit
            title="Build Better Products Faster"
            description="Create exceptional user experiences with our comprehensive design system and component library"
            tag="New Release"
            imageSrc="/placeholders/placeholder4.webp"
            imagePosition="right"
            fixedMediaHeight={true}
            buttons={[
              { text: "Start Building Build", href: "https://webild.io" },
              { text: "View Demo", href: "about" },
            ]}
          />
        </div>

        <SocialProofOne
          title="Trusted by Industry Leaders"
          description="Join thousands of teams building with our platform"
          tag="Social Proof"
          textboxLayout="default"
          logos={[
            "/placeholders/placeholder4.webp",
            "/placeholders/placeholder4.webp",
            "/placeholders/placeholder4.webp",
            "/placeholders/placeholder4.webp",
            "/placeholders/placeholder4.webp",
            "/placeholders/placeholder4.webp",
          ]}
        />

        <div id="about">
          <SplitAbout
            tag="Features"
            title="About Our Platform"
            description="We're on a mission to help teams build beautiful products with modern design patterns and best practices"
            textboxLayout="split"
            bulletPoints={[
              {
                icon: Zap,
                title: "Lightning Fast",
                description: "Optimized for performance and speed",
              },
              {
                icon: Target,
                title: "Precise Design",
                description: "Pixel-perfect components built with care",
              },
              {
                icon: Users,
                title: "Team Focused",
                description: "Built for collaboration and scale",
              },
            ]}
            imageSrc="/placeholders/placeholder4.webp"
            imagePosition="right"
            buttons={[
              { text: "Learn More", href: "features" },
              { text: "Contact Us", href: "https://webild.io/contact" },
            ]}
          />
        </div>

        <MetricCardOne
          title="Our Impact in Numbers - Card One"
          description="Icon-based metric display with detailed descriptions"
          tag="Metrics"
          tagIcon={TrendingUp}
          gridVariant="uniform-all-items-equal"
          animationType="blur-reveal"
          // gridVariant="two-columns-alternating-heights"
          // gridVariant="asymmetric-60-wide-40-narrow"
          // gridVariant="three-columns-all-equal-width"
          // gridVariant="four-items-2x2-equal-grid"
          // gridVariant="one-large-right-three-stacked-left"
          // gridVariant="items-top-row-full-width-bottom"
          // gridVariant="full-width-top-items-bottom-row"
          // gridVariant="one-large-left-three-stacked-right"
          textboxLayout="default"
          metrics={[
            {
              id: "users",
              icon: Users,
              value: "50K+",
              title: "Active Users",
              description: "Growing community worldwide",
            },
            {
              id: "projects",
              icon: Package,
              value: "10K+",
              title: "Projects Built",
              description: "Successful implementations",
            },
            {
              id: "satisfaction",
              icon: Target,
              value: "99%",
              title: "Satisfaction",
              description: "Customer approval rating",
            },
            {
              id: "performance",
              icon: Zap,
              value: "2x",
              title: "Faster Development",
              description: "Time saved on average",
            },
            {
              id: "performance",
              icon: Zap,
              value: "2x",
              title: "Faster Development",
              description: "Time saved on average",
            },
          ]}
        />

        <MetricCardTwo
          title="Our Impact in Numbers - Card Two"
          description="Simple metric display focused on values"
          tag="Metrics"
          tagIcon={TrendingUp}
          gridVariant="uniform-all-items-equal"
          animationType="blur-reveal"
          // gridVariant="two-columns-alternating-heights"
          // gridVariant="asymmetric-60-wide-40-narrow"
          // gridVariant="three-columns-all-equal-width"
          // gridVariant="four-items-2x2-equal-grid"
          // gridVariant="one-large-right-three-stacked-left"
          // gridVariant="items-top-row-full-width-bottom"
          // gridVariant="full-width-top-items-bottom-row"
          // gridVariant="one-large-left-three-stacked-right"
          textboxLayout="default"
          metrics={[
            {
              id: "users",
              value: "50K+",
              description: "Active Users Worldwide",
            },
            {
              id: "projects",
              value: "10K+",
              description: "Projects Successfully Built",
            },
            {
              id: "satisfaction",
              value: "99%",
              description: "Customer Satisfaction Rate",
            },
            {
              id: "performance",
              value: "2x",
              description: "Faster Development Speed",
            },
          ]}
        />

        <MetricCardThree
          title="Our Impact in Numbers - Card Three"
          description="Icon badge with title and value"
          tag="Metrics"
          tagIcon={TrendingUp}
          gridVariant="uniform-all-items-equal"
          animationType="slide-up"
          // gridVariant="two-columns-alternating-heights"
          // gridVariant="asymmetric-60-wide-40-narrow"
          // gridVariant="three-columns-all-equal-width"
          // gridVariant="four-items-2x2-equal-grid"
          // gridVariant="one-large-right-three-stacked-left"
          // gridVariant="items-top-row-full-width-bottom"
          // gridVariant="full-width-top-items-bottom-row"
          // gridVariant="one-large-left-three-stacked-right"
          textboxLayout="default"
          metrics={[
            {
              id: "users",
              icon: Users,
              title: "Active Users",
              value: "50K+",
            },
            {
              id: "projects",
              icon: Package,
              title: "Projects Built",
              value: "10K+",
            },
            {
              id: "satisfaction",
              icon: Target,
              title: "Satisfaction",
              value: "99%",
            },
            {
              id: "performance",
              icon: Zap,
              title: "Faster Development",
              value: "2x",
            },
          ]}
        />

        <div id="features">
          <FeatureCardOne
            title="Powerful Features"
            description="Everything you need to build modern web applications"
            tag="Features"
            textboxLayout="split-actions"
            // gridVariant="timeline"
            gridVariant="uniform-all-items-equal"
            // gridVariant="two-columns-alternating-heights"
            // gridVariant="asymmetric-60-wide-40-narrow"
            // gridVariant="three-columns-all-equal-width"
            // gridVariant="four-items-2x2-equal-grid"
            // gridVariant="one-large-right-three-stacked-left"
            // gridVariant="items-top-row-full-width-bottom"
            // gridVariant="full-width-top-items-bottom-row"
            // gridVariant="one-large-left-three-stacked-right"
            animationType="slide-up"
            // animationType="opacity"
            // animationType="none"
            features={[
              {
                title: "Responsive Design",
                description:
                  "All components are fully responsive and mobile-first",
                imageSrc: "/placeholders/placeholder4.webp",
              },
              {
                title: "Dark Mode Support",
                description: "Built-in theme support with easy customization",
                imageSrc: "/placeholders/placeholder4.webp",
              },
              {
                title: "Type Safe",
                description: "Full TypeScript support for better development",
                imageSrc: "/placeholders/placeholder4.webp",
              },
              {
                title: "Accessible",
                description: "WCAG compliant components out of the box",
                imageSrc: "/placeholders/placeholder4.webp",
              },
              // {
              //   title: "Type Safe",
              //   description: "Full TypeScript support for better development",
              //   imageSrc: "/placeholders/placeholder4.webp",
              // },
              // {
              //   title: "Accessible",
              //   description: "WCAG compliant components out of the box",
              //   imageSrc: "/placeholders/placeholder4.webp",
              // },
            ]}
            buttons={[{ text: "View All Features", href: "products" }]}
          />

          <FeatureCardTwo
            title="Powerful Features - Card Two"
            description="Icon-based features with action buttons"
            tag="Features"
            textboxLayout="default"
            animationType="slide-up"
            gridVariant="uniform-all-items-equal"
            // gridVariant="two-columns-alternating-heights"
            // gridVariant="asymmetric-60-wide-40-narrow"
            // gridVariant="three-columns-all-equal-width"
            // gridVariant="four-items-2x2-equal-grid"
            // gridVariant="one-large-right-three-stacked-left"
            // gridVariant="items-top-row-full-width-bottom"
            // gridVariant="full-width-top-items-bottom-row"
            // gridVariant="one-large-left-three-stacked-right"
            features={[
              {
                icon: Zap,
                title: "Responsive Design",
                description: "All components are fully responsive and mobile-first",
                button: { text: "Learn More", href: "#" },
              },
              {
                icon: Target,
                title: "Dark Mode Support",
                description: "Built-in theme support with easy customization",
                button: { text: "Learn More", href: "#" },
              },
              {
                icon: Users,
                title: "Type Safe",
                description: "Full TypeScript support for better development",
                button: { text: "Learn More", href: "#" },
              },
              {
                icon: Package,
                title: "Accessible",
                description: "WCAG compliant components out of the box",
                button: { text: "Learn More", href: "#" },
              },
            ]}
          />

          <FeatureCardThree
            title="Powerful Features - Card Three"
            description="Image-based features with descriptions"
            tag="Features"
            textboxLayout="default"
            animationType="slide-up"
            gridVariant="uniform-all-items-equal"
            // gridVariant="two-columns-alternating-heights"
            // gridVariant="asymmetric-60-wide-40-narrow"
            // gridVariant="three-columns-all-equal-width"
            // gridVariant="four-items-2x2-equal-grid"
            // gridVariant="one-large-right-three-stacked-left"
            // gridVariant="items-top-row-full-width-bottom"
            // gridVariant="full-width-top-items-bottom-row"
            // gridVariant="one-large-left-three-stacked-right"
            features={[
              {
                id: "feature1",
                title: "Responsive Design",
                description: "All components are fully responsive and mobile-first",
                imageSrc: "/placeholders/placeholder4.webp",
              },
              {
                id: "feature2",
                title: "Dark Mode Support",
                description: "Built-in theme support with easy customization",
                imageSrc: "/placeholders/placeholder4.webp",
              },
              {
                id: "feature3",
                title: "Type Safe",
                description: "Full TypeScript support for better development",
                imageSrc: "/placeholders/placeholder4.webp",
              },
              {
                id: "feature4",
                title: "Accessible",
                description: "WCAG compliant components out of the box",
                imageSrc: "/placeholders/placeholder4.webp",
              },
            ]}
          />

          <FeatureCardSeven
            title="Vertical Feature Stack - Card Seven"
            description="Sequential features with numbered badges in a vertical layout"
            tag="Features"
            textboxLayout="default"
            animationType="blur-reveal"
            features={[
              {
                id: 1,
                title: "Modern Architecture",
                description: "Built with the latest technologies and best practices for optimal performance",
                imageSrc: "/placeholders/placeholder4.webp",
              },
              {
                id: 2,
                title: "Developer Experience",
                description: "Intuitive APIs and comprehensive documentation for rapid development",
                imageSrc: "/placeholders/placeholder3.avif",
              },
              {
                id: 3,
                title: "Production Ready",
                description: "Battle-tested components used by thousands of developers worldwide",
                imageSrc: "/placeholders/placeholder4.webp",
              },
            ]}
          />
        </div>

        <div id="products">
          <ProductCardOne
            title="Our Product Collection - Card One"
            description="Simple product display with favorites"
            tag="Products"
            tagIcon={Package}
            gridVariant="uniform-all-items-equal"
            animationType="slide-up"
            // gridVariant="two-columns-alternating-heights"
            // gridVariant="asymmetric-60-wide-40-narrow"
            // gridVariant="three-columns-all-equal-width"
            // gridVariant="four-items-2x2-equal-grid"
            // gridVariant="one-large-right-three-stacked-left"
            // gridVariant="items-top-row-full-width-bottom"
            // gridVariant="full-width-top-items-bottom-row"
            // gridVariant="one-large-left-three-stacked-right"
            textboxLayout="default"
            products={[
              {
                id: "product1",
                name: "Premium Design Kit",
                price: "$99.00",
                imageSrc: "/placeholders/placeholder4.webp",
                onProductClick: () => console.log("Product 1 clicked"),
              },
              {
                id: "product2",
                name: "Component Library",
                price: "$149.00",
                imageSrc: "/placeholders/placeholder4.webp",
                onProductClick: () => console.log("Product 2 clicked"),
              },
              {
                id: "product3",
                name: "Full Platform Access",
                price: "$299.00",
                imageSrc: "/placeholders/placeholder4.webp",
                onProductClick: () => console.log("Product 3 clicked"),
              },
              {
                id: "product4",
                name: "Enterprise Bundle",
                price: "$499.00",
                imageSrc: "/placeholders/placeholder4.webp",
                onProductClick: () => console.log("Product 4 clicked"),
              },
            ]}
          />

          <ProductCardTwo
            title="Our Product Collection - Card Two"
            description="Product display with ratings and reviews"
            tag="Products"
            tagIcon={Package}
            gridVariant="uniform-all-items-equal"
            animationType="slide-up"
            // gridVariant="two-columns-alternating-heights"
            // gridVariant="asymmetric-60-wide-40-narrow"
            // gridVariant="three-columns-all-equal-width"
            // gridVariant="four-items-2x2-equal-grid"
            // gridVariant="one-large-right-three-stacked-left"
            // gridVariant="items-top-row-full-width-bottom"
            // gridVariant="full-width-top-items-bottom-row"
            // gridVariant="one-large-left-three-stacked-right"
            textboxLayout="default"
            products={[
              {
                id: "product1",
                brand: "Webild",
                name: "Premium Design Kit",
                price: "$99.00",
                rating: 4.5,
                reviewCount: "256",
                imageSrc: "/placeholders/placeholder4.webp",
                onProductClick: () => console.log("Product 1 clicked"),
              },
              {
                id: "product2",
                brand: "Webild",
                name: "Component Library",
                price: "$149.00",
                rating: 5.0,
                reviewCount: "512",
                imageSrc: "/placeholders/placeholder4.webp",
                onProductClick: () => console.log("Product 2 clicked"),
              },
              {
                id: "product3",
                brand: "Webild",
                name: "Full Platform Access",
                price: "$299.00",
                rating: 4.8,
                reviewCount: "384",
                imageSrc: "/placeholders/placeholder4.webp",
                onProductClick: () => console.log("Product 3 clicked"),
              },
              {
                id: "product4",
                brand: "Webild",
                name: "Enterprise Bundle",
                price: "$499.00",
                rating: 4.9,
                reviewCount: "192",
                imageSrc: "/placeholders/placeholder4.webp",
                onProductClick: () => console.log("Product 4 clicked"),
              },
            ]}
          />

          <ProductCardThree
            title="Our Product Collection"
            description="Discover our curated selection of premium products"
            tag="Products"
            tagIcon={Package}
            gridVariant="uniform-all-items-equal"
            animationType="slide-up"
            // gridVariant="two-columns-alternating-heights"
            // gridVariant="asymmetric-60-wide-40-narrow"
            // gridVariant="three-columns-all-equal-width"
            // gridVariant="four-items-2x2-equal-grid"
            // gridVariant="one-large-right-three-stacked-left"
            // gridVariant="items-top-row-full-width-bottom"
            // gridVariant="full-width-top-items-bottom-row"
            // gridVariant="one-large-left-three-stacked-right"
            textboxLayout="split"
            products={[
              {
                id: "product1",
                name: "Premium Design Kit",
                price: "$99.00",
                imageSrc: "/placeholders/placeholder4.webp",
                onProductClick: () => console.log("Product 1 clicked"),
                onQuantityChange: (qty) => console.log("Product 1 quantity:", qty),
              },
              {
                id: "product2",
                name: "Component Library",
                price: "$149.00",
                imageSrc: "/placeholders/placeholder4.webp",
                onProductClick: () => console.log("Product 2 clicked"),
                onQuantityChange: (qty) => console.log("Product 2 quantity:", qty),
              },
              {
                id: "product3",
                name: "Full Platform Access",
                price: "$299.00",
                imageSrc: "/placeholders/placeholder4.webp",
                onProductClick: () => console.log("Product 3 clicked"),
                onQuantityChange: (qty) => console.log("Product 3 quantity:", qty),
              },
              {
                id: "product4",
                name: "Enterprise Bundle",
                price: "$499.00",
                imageSrc: "/placeholders/placeholder4.webp",
                onProductClick: () => console.log("Product 4 clicked"),
                onQuantityChange: (qty) => console.log("Product 4 quantity:", qty),
              },
              // {
              //   id: "product5",
              //   name: "Starter Pack",
              //   price: "$49",
              //   imageSrc: "/placeholders/placeholder4.webp",
              // },
            ]}
            buttons={[{ text: "View All Products", href: "pricing" }]}
          />
        </div>

        <div id="pricing">
          <PricingCardOne
            title="Simple, Transparent Pricing"
            description="Choose the plan that works best for you"
            tag="Pricing"
            textboxLayout="default"
            animationType="slide-up"
            plans={[
              {
                id: "starter",
                badge: "Starter",
                price: "29",
                subtitle: "Perfect for small projects",
                features: [
                  "Access to all components",
                  "Basic support",
                  "Free updates",
                ],
              },
              {
                id: "professional",
                badge: "Professional",
                price: "99",
                subtitle: "For growing teams",
                features: [
                  "Everything in Starter",
                  "Priority support",
                  "Advanced components",
                  "Team collaboration",
                ],
              },
              {
                id: "enterprise",
                badge: "Enterprise",
                price: "299",
                subtitle: "For large organizations",
                features: [
                  "Everything in Professional",
                  "Dedicated support",
                  "Custom components",
                  "SLA guarantee",
                ],
              },
              {
                id: "enterprise",
                badge: "Enterprise",
                price: "299",
                subtitle: "For large organizations",
                features: [
                  "Everything in Professional",
                  "Dedicated support",
                  "Custom components",
                  "SLA guarantee",
                ],
              },
            ]}
          />

          <PricingCardTwo
            title="Simple, Transparent Pricing - Card Two"
            description="Plan cards with action buttons"
            tag="Pricing"
            textboxLayout="default"
            animationType="slide-up"
            plans={[
              {
                id: "starter",
                badge: "Starter",
                badgeIcon: Zap,
                price: "29",
                subtitle: "Perfect for small projects",
                buttons: [{ text: "Get Started", href: "#" }],
                features: [
                  "Access to all components",
                  "Basic support",
                  "Free updates",
                ],
              },
              {
                id: "professional",
                badge: "Professional",
                badgeIcon: Target,
                price: "99",
                subtitle: "For growing teams",
                buttons: [{ text: "Get Started", href: "#" }],
                features: [
                  "Everything in Starter",
                  "Priority support",
                  "Advanced components",
                  "Team collaboration",
                ],
              },
              {
                id: "enterprise",
                badge: "Enterprise",
                badgeIcon: Users,
                price: "299",
                subtitle: "For large organizations",
                buttons: [{ text: "Contact Sales", href: "#" }],
                features: [
                  "Everything in Professional",
                  "Dedicated support",
                  "Custom components",
                  "SLA guarantee",
                ],
              },
            ]}
          />

          <PricingCardThree
            title="Simple, Transparent Pricing - Card Three"
            description="Minimal pricing cards"
            tag="Pricing"
            textboxLayout="default"
            animationType="slide-up"
            plans={[
              {
                id: "starter",
                price: "29",
                name: "Starter",
                buttons: [{ text: "Get Started", href: "#" }],
                features: [
                  "Access to all components",
                  "Basic support",
                  "Free updates",
                ],
              },
              {
                id: "professional",
                badgeIcon: TrendingUp,
                badge: "Popular",
                price: "99",
                name: "Professional",
                buttons: [{ text: "Get Started", href: "#" }],
                features: [
                  "Everything in Starter",
                  "Priority support",
                  "Advanced components",
                  "Team collaboration",
                ],
              },
              {
                id: "enterprise",
                price: "299",
                name: "Enterprise",
                buttons: [{ text: "Contact Sales", href: "#" }],
                features: [
                  "Everything in Professional",
                  "Dedicated support",
                  "Custom components",
                  "SLA guarantee",
                ],
              },
            ]}
          />
        </div>

        <TestimonialCardOne
          title="What Our Customers Say - Card One"
          description="Image-based testimonials with ratings"
          tag="Testimonials"
          gridVariant="uniform-all-items-equal"
          textboxLayout="default"
          animationType="slide-up"
          testimonials={[
            {
              id: "testimonial1",
              name: "Sarah Johnson",
              role: "CEO",
              company: "Tech Corp",
              rating: 5,
              imageSrc: "/placeholders/placeholder3.avif",
            },
            {
              id: "testimonial2",
              name: "Michael Chen",
              role: "Lead Developer",
              company: "Design Studio",
              rating: 5,
              imageSrc: "/placeholders/placeholder4.webp",
            },
            {
              id: "testimonial3",
              name: "Emily Rodriguez",
              role: "Product Manager",
              company: "Innovation Labs",
              rating: 5,
              imageSrc: "/placeholders/placeholder3.avif",
            },
            {
              id: "testimonial4",
              name: "David Kim",
              role: "CTO",
              company: "Future Systems",
              rating: 5,
              imageSrc: "/placeholders/placeholder4.webp",
            },
          ]}
        />

        <TestimonialCardTwo
          title="What Our Customers Say - Card Two"
          description="Icon-based testimonials"
          tag="Testimonials"
          textboxLayout="default"
          animationType="slide-up"
          testimonials={[
            {
              id: "testimonial1",
              name: "Sarah Johnson",
              role: "CEO at Tech Corp",
              testimonial: "This platform has completely transformed how we approach design. The components are beautiful and incredibly easy to customize.",
              icon: Package,
            },
            {
              id: "testimonial2",
              name: "Michael Chen",
              role: "Lead Developer",
              testimonial: "The best component library I've used. It's saved our team countless hours and the code quality is exceptional.",
              icon: Zap,
            },
            {
              id: "testimonial3",
              name: "Emily Rodriguez",
              role: "Product Manager",
              testimonial: "Our development velocity has doubled since adopting this platform. The attention to detail is remarkable.",
              icon: Target,
            },
            {
              id: "testimonial4",
              name: "David Kim",
              role: "CTO",
              testimonial: "Outstanding build quality and TypeScript support. This has become an essential part of our tech stack.",
              icon: TrendingUp,
            },
          ]}
        />

        <TestimonialCardThree
          title="What Our Customers Say"
          description="Real stories from real customers"
          tag="Testimonials"
          textboxLayout="default"
          animationType="slide-up"
          testimonials={[
            {
              id: "testimonial1",
              name: "Sarah",
              handle: "@sarahj",
              testimonial: "This platform has completely transformed how we approach design. The components are beautiful and incredibly easy to customize.",
              icon: Package,
            },
            {
              id: "testimonial2",
              name: "Michael",
              handle: "@mchen",
              testimonial: "The best component library I've used. It's saved our team countless hours and the code quality is exceptional.",
              icon: Zap,
            },
            {
              id: "testimonial3",
              name: "Emily",
              handle: "@emily_r",
              testimonial: "Our development velocity has doubled since adopting this platform. The attention to detail is remarkable.",
              icon: Target,
            },
            {
              id: "testimonial4",
              name: "David",
              handle: "@davidkim",
              testimonial: "Outstanding build quality and TypeScript support. This has become an essential part of our tech stack.",
              icon: TrendingUp,
            },
          ]}
        />

        <FaqBase
          title="Frequently Asked Questions"
          description="Everything you need to know about our platform"
          tag="FAQ"
          textboxLayout="default"
          faqs={[
            {
              id: "faq1",
              title: "How do I get started?",
              content: "Getting started is easy! Simply sign up for an account, choose your plan, and you'll have instant access to all our components and tools.",
            },
            {
              id: "faq2",
              title: "What's included in the pricing?",
              content: "All plans include access to our component library, regular updates, documentation, and community support. Higher tiers include priority support and advanced features.",
            },
            {
              id: "faq3",
              title: "Can I cancel anytime?",
              content: "Yes, you can cancel your subscription at any time. There are no long-term contracts or cancellation fees.",
            },
            {
              id: "faq4",
              title: "Do you offer refunds?",
              content: "We offer a 30-day money-back guarantee. If you're not satisfied with your purchase, contact us within 30 days for a full refund.",
            },
            {
              id: "faq5",
              title: "Is there a free trial?",
              content: "Yes! We offer a 14-day free trial on all plans. No credit card required to get started.",
            },
          ]}
        />

        <div id="blog">
          <BlogCardOne
            title="Latest from Our Blog"
            description="Stay updated with the latest news, tips, and insights"
            tag="Blog"
            textboxLayout="split-actions"
            animationType="slide-up"
            blogs={[
              {
                id: "blog1",
                category: "Design",
                title: "10 Design Principles for Modern Web Apps",
                excerpt: "Learn the key principles that make modern web applications beautiful and functional.",
                imageSrc: "/placeholders/placeholder4.webp",
                authorName: "Sarah Chen",
                authorAvatar: "/placeholders/placeholder4.webp",
                date: "Mar 15, 2025",
              },
              {
                id: "blog2",
                category: "Development",
                title: "Building Scalable Component Libraries",
                excerpt: "A comprehensive guide to creating component libraries that grow with your team.",
                imageSrc: "/placeholders/placeholder4.webp",
                authorName: "Marcus Lee",
                authorAvatar: "/placeholders/placeholder4.webp",
                date: "Mar 12, 2025",
              },
              {
                id: "blog3",
                category: "Tutorial",
                title: "Getting Started with Next.js 15",
                excerpt: "Everything you need to know about the latest Next.js release and how to use it.",
                imageSrc: "/placeholders/placeholder4.webp",
                authorName: "Emily Taylor",
                authorAvatar: "/placeholders/placeholder4.webp",
                date: "Mar 10, 2025",
              },
              {
                id: "blog4",
                category: "Case Study",
                title: "How We Built Our Design System",
                excerpt: "Behind the scenes look at building a comprehensive design system from scratch.",
                imageSrc: "/placeholders/placeholder4.webp",
                authorName: "Alex Johnson",
                authorAvatar: "/placeholders/placeholder4.webp",
                date: "Mar 8, 2025",
              },
              {
                id: "blog5",
                category: "Best Practices",
                title: "Accessibility in Modern Web Design",
                excerpt: "Essential accessibility practices every developer should know and implement.",
                imageSrc: "/placeholders/placeholder4.webp",
                authorName: "Jordan Smith",
                authorAvatar: "/placeholders/placeholder4.webp",
                date: "Mar 5, 2025",
              },
            ]}
            buttons={[{ text: "View All Posts", href: "https://webild.io/blog" }]}
          />

          <BlogCardTwo
            title="Latest from Our Blog - Card Two"
            description="Tag-based blog cards"
            tag="Blog"
            textboxLayout="default"
            animationType="slide-up"
            blogs={[
              {
                id: "blog1",
                tags: ["Design", "UI/UX"],
                title: "10 Design Principles for Modern Web Apps",
                excerpt: "Learn the key principles that make modern web applications beautiful and functional.",
                imageSrc: "/placeholders/placeholder4.webp",
                authorName: "Sarah Chen",
                date: "Mar 15, 2025",
              },
              {
                id: "blog2",
                tags: ["Development", "React"],
                title: "Building Scalable Component Libraries",
                excerpt: "A comprehensive guide to creating component libraries that grow with your team.",
                imageSrc: "/placeholders/placeholder4.webp",
                authorName: "Marcus Lee",
                date: "Mar 12, 2025",
              },
              {
                id: "blog3",
                tags: ["Tutorial", "Next.js"],
                title: "Getting Started with Next.js 15",
                excerpt: "Everything you need to know about the latest Next.js release and how to use it.",
                imageSrc: "/placeholders/placeholder4.webp",
                authorName: "Emily Taylor",
                date: "Mar 10, 2025",
              },
              {
                id: "blog4",
                tags: ["Case Study"],
                title: "How We Built Our Design System",
                excerpt: "Behind the scenes look at building a comprehensive design system from scratch.",
                imageSrc: "/placeholders/placeholder4.webp",
                authorName: "Alex Johnson",
                date: "Mar 8, 2025",
              },
            ]}
          />
        </div>

        <div id="team">
          <TeamCardOne
            title="Meet Our Team - Card One"
            description="Simple team member cards"
            tag="Team"
            textboxLayout="default"
            animationType="slide-up"
            gridVariant="uniform-all-items-equal"
            // gridVariant="two-columns-alternating-heights"
            // gridVariant="asymmetric-60-wide-40-narrow"
            // gridVariant="three-columns-all-equal-width"
            // gridVariant="four-items-2x2-equal-grid"
            // gridVariant="one-large-right-three-stacked-left"
            // gridVariant="items-top-row-full-width-bottom"
            // gridVariant="full-width-top-items-bottom-row"
            // gridVariant="one-large-left-three-stacked-right"
            members={[
              {
                id: "alex",
                name: "Alex Johnson",
                role: "CEO & Founder",
                imageSrc: "/placeholders/placeholder4.webp",
              },
              {
                id: "sarah",
                name: "Sarah Chen",
                role: "Head of Design",
                imageSrc: "/placeholders/placeholder3.avif",
              },
              {
                id: "marcus",
                name: "Marcus Rodriguez",
                role: "Lead Engineer",
                imageSrc: "/placeholders/placeholder4.webp",
              },
              {
                id: "emily",
                name: "Emily Taylor",
                role: "Product Manager",
                imageSrc: "/placeholders/placeholder3.avif",
              },
            ]}
          />

          <TeamCardTwo
            title="Meet Our Team - Card Two"
            description="Team cards with descriptions and social links"
            tag="Team"
            textboxLayout="default"
            animationType="slide-up"
            gridVariant="uniform-all-items-equal"
            // gridVariant="two-columns-alternating-heights"
            // gridVariant="asymmetric-60-wide-40-narrow"
            // gridVariant="three-columns-all-equal-width"
            // gridVariant="four-items-2x2-equal-grid"
            // gridVariant="one-large-right-three-stacked-left"
            // gridVariant="items-top-row-full-width-bottom"
            // gridVariant="full-width-top-items-bottom-row"
            // gridVariant="one-large-left-three-stacked-right"
            members={[
              {
                id: "alex",
                name: "Alex Johnson",
                role: "CEO & Founder",
                description: "Leading the vision and strategy for our platform",
                imageSrc: "/placeholders/placeholder4.webp",
                socialLinks: [{ icon: Mail, url: "#" }, { icon: Users, url: "#" }],
              },
              {
                id: "sarah",
                name: "Sarah Chen",
                role: "Head of Design",
                description: "Creating beautiful and intuitive user experiences",
                imageSrc: "/placeholders/placeholder3.avif",
                socialLinks: [{ icon: Mail, url: "#" }, { icon: Users, url: "#" }],
              },
              {
                id: "marcus",
                name: "Marcus Rodriguez",
                role: "Lead Engineer",
                description: "Building robust and scalable systems",
                imageSrc: "/placeholders/placeholder4.webp",
                socialLinks: [{ icon: Mail, url: "#" }, { icon: Users, url: "#" }],
              },
              {
                id: "emily",
                name: "Emily Taylor",
                role: "Product Manager",
                description: "Ensuring we build what our users need",
                imageSrc: "/placeholders/placeholder3.avif",
                socialLinks: [{ icon: Mail, url: "#" }, { icon: Users, url: "#" }],
              },
            ]}
          />

          <TeamCardThree
            title="Meet Our Team"
            description="The talented people behind our platform"
            tag="Team"
            textboxLayout="default"
            animationType="slide-up"
            members={[
              {
                id: "alex",
                name: "Alex Johnson",
                role: "CEO & Founder",
                imageSrc: "/placeholders/placeholder4.webp",
                socialLinks: [{ icon: Mail, url: "#" }, { icon: Users, url: "#" }],
              },
              {
                id: "sarah",
                name: "Sarah Chen",
                role: "Head of Design",
                imageSrc: "/placeholders/placeholder4.webp",
                socialLinks: [{ icon: Mail, url: "#" }, { icon: Users, url: "#" }],
              },
              {
                id: "marcus",
                name: "Marcus Rodriguez",
                role: "Lead Engineer",
                imageSrc: "/placeholders/placeholder4.webp",
                socialLinks: [{ icon: Mail, url: "#" }, { icon: Users, url: "#" }],
              },
              {
                id: "emily",
                name: "Emily Taylor",
                role: "Product Manager",
                imageSrc: "/placeholders/placeholder4.webp",
                socialLinks: [{ icon: Mail, url: "#" }, { icon: Users, url: "#" }],
              },
            ]}
          />
        </div>

        <div id="contact">
          <ContactCenter
            title="Get Started Today"
            description="Join thousands of developers building amazing products"
            tag="Contact"
            tagIcon={Mail}
            inputPlaceholder="Enter your email"
            buttonText="Get Started"
            onSubmit={(email) => console.log("Submitted:", email)}
          />
        </div>

        <FooterBase
          columns={footerColumns}
          copyrightText="© 2025 | Example Company"
          onPrivacyClick={() => console.log("Privacy clicked")}
        />
      </ThemeProvider>
    </>
  );
}
