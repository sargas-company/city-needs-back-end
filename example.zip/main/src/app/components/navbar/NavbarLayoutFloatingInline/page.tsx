"use client";

import NavbarLayoutFloatingInline from "@/components/navbar/NavbarLayoutFloatingInline";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import ReactLenis from "lenis/react";
import type { NavItem } from "@/types/navigation";

const navItems: NavItem[] = [
  { name: "Home", id: "home" },
  { name: "About", id: "about" },
  { name: "Services", id: "services" },
  { name: "Contact", id: "contact" },
];

export default function NavbarLayoutFloatingInlinePage() {
  return (
    <ReactLenis root>
      <ThemeProvider
        defaultButtonVariant="text-stagger"
        defaultTextAnimation="entrance-slide"
        borderRadius="rounded" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass"
      >
        <NavbarLayoutFloatingInline
          navItems={navItems}
          button={{ text: "Get Started", href: "https://webild.io" }}
        />
        <section id="home" className="relative h-screen min-h-screen w-full flex items-center justify-center">
          <h1 className="text-4xl font-bold text-foreground">Home Section</h1>
        </section>
        <section id="about" className="relative h-screen min-h-screen w-full flex items-center justify-center">
          <h1 className="text-4xl font-bold text-foreground">About Section</h1>
        </section>
        <section id="services" className="relative h-screen min-h-screen w-full flex items-center justify-center">
          <h1 className="text-4xl font-bold text-foreground">Services Section</h1>
        </section>
        <section id="contact" className="relative h-screen min-h-screen w-full flex items-center justify-center">
          <h1 className="text-4xl font-bold text-foreground">Contact Section</h1>
        </section>
      </ThemeProvider>
    </ReactLenis>
  );
}