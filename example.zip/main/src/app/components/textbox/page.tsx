"use client";

import ReactLenis from "lenis/react";
import Textbox from "@/components/Textbox";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function TextBoxPage() {
    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="rounded" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
            <section className="h-screen flex items-center justify-center">
                <p className="text-xl text-black">Scroll</p>
            </section>
            <section className="h-screen flex items-center justify-center">
                <Textbox
                    title="Welcome to our platform"
                    description="Experience the next generation of digital solutions with our innovative tools and seamless integration"
                    type="entrance-slide"
                />
            </section>
            <section className="h-screen flex items-center justify-center">
                <Textbox
                    title="Discover new possibilities"
                    description="Transform your workflow with powerful features designed to enhance productivity and creativity"
                    type="reveal-blur"
                />
            </section>
            <section className="h-screen flex items-center justify-center">
                <Textbox
                    title="Join our community"
                    description="Connect with thousands of professionals and unlock exclusive resources to accelerate your growth"
                    type="background-highlight"
                    buttons={[
                        { text: "Get Started", onClick: () => console.log("Get Started") },
                        { text: "Learn More", onClick: () => console.log("Learn More") },
                    ]}
                    avatars={[
                        { src: "/placeholders/placeholder1.webp", alt: "User 1" },
                        { src: "/placeholders/placeholder2.jpg", alt: "User 2" },
                        { src: "/placeholders/placeholder3.avif", alt: "User 3" },
                        { src: "/placeholders/placeholder4.webp", alt: "User 4" },
                        { src: "/placeholders/placeholder5.jpg", alt: "User 5" },
                        { src: "/placeholders/placeholder3.avif", alt: "User 3" },
                        { src: "/placeholders/placeholder4.webp", alt: "User 4" },
                        { src: "/placeholders/placeholder5.jpg", alt: "User 5" },
                    ]}
                    avatarText="Join 1,000+ members"
                />
            </section>
            <section className="h-screen flex items-center justify-center">
                <p className="text-xl text-black">End</p>
            </section>
        </ReactLenis>
        </ThemeProvider>
    );
}