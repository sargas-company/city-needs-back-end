"use client";

import ReactLenis from "lenis/react";
import TextAnimation from "@/components/text/TextAnimation";

export default function TextAnimationPage() {
    return (
        <ReactLenis root>
            <section className="h-screen flex items-center justify-center" >
                <p className="text-xl text-black" >Scroll</p>
            </section>
            <section className="h-screen flex items-center justify-center" >
                <TextAnimation
                    type="entrance-slide"
                    text="Entrance Slide Animation"
                    className="text-5xl font-medium"
                    variant="trigger"
                />
            </section>
            <section className="h-screen flex items-center justify-center" >
                <TextAnimation
                    type="reveal-blur"
                    text="Reveal Blur Animation"
                    className="text-5xl font-medium"
                    variant="trigger"
                />
            </section>
            <section className="h-screen flex items-center justify-center" >
                <TextAnimation
                    type="background-highlight"
                    text="Background Highlight Animation"
                    className="text-5xl font-medium"
                    variant="trigger"
                />
            </section>
            <section className="h-screen flex items-center justify-center" >
                <p className="text-xl text-black" >End</p>
            </section>
        </ReactLenis>
    );
}