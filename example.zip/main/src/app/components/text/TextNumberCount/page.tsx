"use client";

import ReactLenis from "lenis/react";
import TextNumberCount from "@/components/text/TextNumberCount";

export default function TextNumberCountPage() {
    return (
        <ReactLenis root>
            <section className="h-screen flex items-center justify-center">
                <p className="text-xl text-black">Scroll</p>
            </section>
            <section className="h-screen flex items-center justify-center">
                <TextNumberCount
                    value={99999}
                    animateOnScroll
                    className="text-5xl font-medium"
                    suffix="+"
                />
            </section>
            <section className="h-screen flex items-center justify-center">
                <TextNumberCount
                    value={49.99}
                    animateOnScroll
                    format={{ style: "currency", currency: "USD" }}
                    className="text-5xl font-medium"
                />
            </section>
            <section className="h-screen flex items-center justify-center">
                <TextNumberCount
                    value={87}
                    animateOnScroll
                    suffix="%"
                    className="text-5xl font-medium"
                />
            </section>
            <section className="h-screen flex items-center justify-center">
                <p className="text-xl text-black">End</p>
            </section>
        </ReactLenis>
    );
}