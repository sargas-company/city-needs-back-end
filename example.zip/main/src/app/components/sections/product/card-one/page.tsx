"use client";

import ProductCardOne from "@/components/sections/product/ProductCardOne";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Star } from "lucide-react";

export default function ProductCardOnePage() {
    const products = [
        {
            id: "1",
            name: "Eclipse Motion Pro",
            price: "$150",
            imageSrc: "/placeholders/placeholder2.jpg",
            imageAlt: "Eclipse Motion Pro sneaker",
            onProductClick: () => window.open("https://apple.com", "_blank"),
        },
        {
            id: "2",
            name: "Velocity Runner",
            price: "$120",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "Velocity Runner sneaker",
            onProductClick: () => window.open("https://apple.com", "_blank"),
        },
        {
            id: "3",
            name: "Urban Stride",
            price: "$95",
            imageSrc: "/placeholders/placeholder2.jpg",
            imageAlt: "Urban Stride sneaker",
            onProductClick: () => window.open("https://apple.com", "_blank"),
        },
        {
            id: "4",
            name: "Cloud Walker",
            price: "$180",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "Cloud Walker sneaker",
            onProductClick: () => window.open("https://apple.com", "_blank"),
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="rounded" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <div className="min-h-screen p-8">
                <ProductCardOne
                    products={products}
                    title="Featured Products"
                    description="Explore our latest collection"
          gridVariant="uniform-all-items-equal"
                textboxLayout="default"
                    // tag="New Arrivals"
                    tagIcon={Star}
                    // buttons={[
                    //     { text: "View All", href: "#" },
                    //     { text: "Shop Now", href: "#" },
                    // ]}
                
                animationType="slide-up"
            />
            </div>
        </ThemeProvider>
    );
}
