"use client";

import ProductCardThree from "@/components/sections/product/ProductCardThree";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function ProductCardThreePage() {
    const products = [
        {
            id: "1",
            name: "TIMBUK2 Classic Messenger Bag",
            price: "$119.00",
            imageSrc: "/placeholders/placeholder3.avif",
            imageAlt: "TIMBUK2 Classic Messenger Bag",
            onProductClick: () => window.open("https://apple.com", "_blank"),
            onQuantityChange: (quantity: number) => console.log(`Quantity changed to ${quantity}`),
        },
        {
            id: "2",
            name: "Urban Commuter Backpack",
            price: "$89.00",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "Urban Commuter Backpack",
            onProductClick: () => window.open("https://apple.com", "_blank"),
            onQuantityChange: (quantity: number) => console.log(`Quantity changed to ${quantity}`),
        },
        {
            id: "3",
            name: "Leather Laptop Bag",
            price: "$149.00",
            imageSrc: "/placeholders/placeholder3.avif",
            imageAlt: "Leather Laptop Bag",
            onProductClick: () => window.open("https://apple.com", "_blank"),
            onQuantityChange: (quantity: number) => console.log(`Quantity changed to ${quantity}`),
        },
        {
            id: "4",
            name: "Travel Duffel Bag",
            price: "$199.00",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "Travel Duffel Bag",
            onProductClick: () => window.open("https://apple.com", "_blank"),
            onQuantityChange: (quantity: number) => console.log(`Quantity changed to ${quantity}`),
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="rounded" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <div className="min-h-screen p-8">
                <ProductCardThree
                    products={products}
                    title="Featured Products"
                    description="Explore our latest collection"
          gridVariant="uniform-all-items-equal"
                textboxLayout="default"
                
                animationType="slide-up"
            />
            </div>
        </ThemeProvider>
    );
}
