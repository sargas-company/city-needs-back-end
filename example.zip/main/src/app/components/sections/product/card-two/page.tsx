"use client";

import ProductCardTwo from "@/components/sections/product/ProductCardTwo";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function ProductCardTwoPage() {
    const products = [
        {
            id: "1",
            brand: "Wofurnitures",
            name: "Single Accent Chair",
            price: "$650.00",
            rating: 4,
            reviewCount: "23.9k",
            imageSrc: "/placeholders/placeholder3.avif",
            imageAlt: "Single Accent Chair",
            onProductClick: () => window.open("https://apple.com", "_blank"),
        },
        {
            id: "2",
            brand: "ModernHome",
            name: "Velvet Lounge Chair",
            price: "$850.00",
            rating: 5,
            reviewCount: "18.2k",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "Velvet Lounge Chair",
            onProductClick: () => window.open("https://apple.com", "_blank"),
        },
        {
            id: "3",
            brand: "UrbanStyle",
            name: "Classic Armchair",
            price: "$720.00",
            rating: 4,
            reviewCount: "15.6k",
            imageSrc: "/placeholders/placeholder3.avif",
            imageAlt: "Classic Armchair",
            onProductClick: () => window.open("https://apple.com", "_blank"),
        },
        {
            id: "4",
            brand: "ComfortCo",
            name: "Designer Chair",
            price: "$920.00",
            rating: 5,
            reviewCount: "31.4k",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "Designer Chair",
            onProductClick: () => window.open("https://apple.com", "_blank"),
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="rounded" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <div className="min-h-screen p-8">
                <ProductCardTwo
                    products={products}
                    title="Featured Products"
                    description="Explore our latest collection"
          gridVariant="uniform-all-items-equal"
                textboxLayout="default"
                
                animationType="slide-up"
            />
            </div>
        </ThemeProvider>
    );
}
