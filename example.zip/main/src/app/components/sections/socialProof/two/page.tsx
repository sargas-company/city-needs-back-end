"use client";

import SocialProofTwo from "@/components/sections/socialProof/SocialProofTwo";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function SocialProofTwoPage() {
    const logos = [
        "/placeholders/placeholder-logo.svg",
        "/placeholders/placeholder-logo.svg",
        "/placeholders/placeholder-logo.svg",
        "/placeholders/placeholder-logo.svg",
        "/placeholders/placeholder-logo.svg",
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="rounded" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <SocialProofTwo
                logos={logos}
                title="Trusted By"
                description="Join thousands of satisfied customers"
                textboxLayout="default"
            />
        </ThemeProvider>
    );
}
