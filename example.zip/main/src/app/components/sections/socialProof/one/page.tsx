"use client";

import SocialProofOne from "@/components/sections/socialProof/SocialProofOne";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function SocialProofOnePage() {
    const logos = [
        "/placeholders/placeholder-logo.svg",
        "/placeholders/placeholder-logo.svg",
        "/placeholders/placeholder-logo.svg",
        "/placeholders/placeholder-logo.svg",
        "/placeholders/placeholder-logo.svg",
        "/placeholders/placeholder-logo.svg",
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="rounded" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <SocialProofOne
                logos={logos}
                title="Trusted By"
                description="Join thousands of satisfied customers"
                textboxLayout="default"
                showCard={true}
            />
        </ThemeProvider>
    );
}
