"use client";

import ReactLenis from "lenis/react";
import ContactCenter from "@/components/sections/contact/ContactCenter";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Mail } from "lucide-react";

export default function ContactCenterPage() {
    const handleSubmit = (email: string) => {
        console.log("Email submitted:", email);
    };

    return (
        <ThemeProvider defaultButtonVariant="hover-bubble" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <ContactCenter
                    tag="Newsletter"
                    tagIcon={Mail}
                    title="Medium length heading goes here"
                    description="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique."
                    inputPlaceholder="Enter your email"
                    buttonText="Sign Up"
                    onSubmit={handleSubmit}
                />
            </ReactLenis>
        </ThemeProvider>
    );
}
