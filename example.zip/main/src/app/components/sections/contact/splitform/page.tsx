"use client";

import ReactLenis from "lenis/react";
import ContactSplitForm from "@/components/sections/contact/ContactSplitForm";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function ContactSplitFormPage() {
    const handleSubmit = (data: Record<string, string>) => {
        console.log("Form submitted:", data);
    };

    return (
        <ThemeProvider defaultButtonVariant="hover-bubble" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <ContactSplitForm
                    title="Contact us"
                    description="Lorem ipsum dolor sit amet, consectetur adipiscing elit."
                    inputs={[
                        { name: "name", type: "text", placeholder: "Name", required: true },
                        { name: "email", type: "email", placeholder: "Email", required: true },
                    ]}
                    textarea={{
                        name: "message",
                        placeholder: "Type your message...",
                        rows: 5,
                        required: true,
                    }}
                    imageSrc="/placeholders/placeholder2.jpg"
                    imageAlt=""
                    mediaPosition="right"
                    onSubmit={handleSubmit}
                />
            </ReactLenis>
        </ThemeProvider>
    );
}
