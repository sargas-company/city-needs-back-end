"use client";

import ReactLenis from "lenis/react";
import ContactCenterForm from "@/components/sections/contact/ContactCenterForm";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function ContactCenterFormPage() {
    const handleSubmit = (data: Record<string, string>) => {
        console.log("Form submitted:", data);
    };

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <ContactCenterForm
                    title="Contact us"
                    description="Lorem ipsum dolor sit amet, consectetur adipiscing elit."
                    inputs={[
                        { name: "name", type: "text", placeholder: "Name", required: true },
                        { name: "email", type: "email", placeholder: "Email", required: true },
                    ]}
                    textarea={{
                        name: "message",
                        placeholder: "Type your message...",
                        rows: 5,
                        required: true,
                    }}
                    onSubmit={handleSubmit}
                />
            </ReactLenis>
        </ThemeProvider>
    );
}
