"use client";

import ReactLenis from "lenis/react";
import ContactSplit from "@/components/sections/contact/ContactSplit";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Mail } from "lucide-react";

export default function ContactSplitPage() {
    const handleSubmit = (email: string) => {
        console.log("Email submitted:", email);
    };

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <ContactSplit
                    tag="Newsletter"
                    tagIcon={Mail}
                    title="Medium length heading goes here"
                    description="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique."
                    imageSrc="/placeholders/placeholder2.jpg"
                    imageAlt=""
                    mediaPosition="right"
                    inputPlaceholder="Enter your email"
                    buttonText="Sign Up"
                    onSubmit={handleSubmit}
                />
            </ReactLenis>
        </ThemeProvider>
    );
}
