"use client";

import MetricCardThree from "@/components/sections/metrics/MetricCardThree";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { TrendingUp, Users, DollarSign } from "lucide-react";

export default function MetricCardThreePage() {
    const metrics = [
        {
            id: "1",
            icon: TrendingUp,
            title: "Conversions",
            value: "7,000+",
        },
        {
            id: "2",
            icon: Users,
            title: "Active Users",
            value: "50,000+",
        },
        {
            id: "3",
            icon: DollarSign,
            title: "Revenue",
            value: "$2M+",
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <div className="min-h-screen p-8">
                <MetricCardThree
                    metrics={metrics}
                    title="Our Impact"
                    description="Key metrics that showcase our growth"
          gridVariant="uniform-all-items-equal"
                textboxLayout="default"
                
                animationType="slide-up"
            />
            </div>
        </ThemeProvider>
    );
}
