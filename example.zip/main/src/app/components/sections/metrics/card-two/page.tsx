"use client";

import MetricCardTwo from "@/components/sections/metrics/MetricCardTwo";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function MetricCardTwoPage() {
    const metrics = [
        {
            id: "1",
            value: "98%",
            description: "Customer Satisfaction Rate",
        },
        {
            id: "2",
            value: "50K+",
            description: "Active Users Worldwide",
        },
        {
            id: "3",
            value: "$2M",
            description: "Annual Revenue Generated",
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <div className="min-h-screen p-8">
                <MetricCardTwo
                    metrics={metrics}
                    title="Our Impact"
                    description="Key metrics that showcase our growth"
          gridVariant="uniform-all-items-equal"
                textboxLayout="default"
                
                animationType="slide-up"
            />
            </div>
        </ThemeProvider>
    );
}
