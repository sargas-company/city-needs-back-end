"use client";

import ReactLenis from "lenis/react";
import MetricCardFour from "@/components/sections/metrics/MetricCardFour";
import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { TrendingUp, Users, DollarSign, Star } from "lucide-react";

export default function MetricCardFourPage() {
    const navItems = [
        { name: "Home", id: "home" },
        { name: "About", id: "about" },
        { name: "Services", id: "services" },
        { name: "Contact", id: "contact" },
    ];

    const metrics = [
        {
            id: "1",
            icon: TrendingUp,
            title: "Growth Rate",
            value: "250%",
            imageSrc: "/placeholderS/placeholder5.jpg",
        },
        {
            id: "2",
            icon: Users,
            title: "Active Users",
            value: "50K+",
            imageSrc: "/placeholderS/placeholder2.jpg",
        },
        {
            id: "3",
            icon: DollarSign,
            title: "Revenue",
            value: "$2.5M",
            imageSrc: "/placeholderS/placeholder3.avif",
        },
        {
            id: "4",
            icon: Star,
            title: "Satisfaction",
            value: "98%",
            imageSrc: "/placeholderS/placeholder4.jpg",
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="layered-gradient" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <NavbarLayoutFloatingOverlay
                    navItems={navItems}
                    brandName="Webild"
                    button={{ text: "Get Started", onClick: () => console.log("Nav button clicked") }}
                />
                <MetricCardFour
                    metrics={metrics}
                    title="Our Impact"
                    description="Key metrics showcasing our growth and success"
                    textboxLayout="default"
                />
            </ReactLenis>
        </ThemeProvider>
    );
}
