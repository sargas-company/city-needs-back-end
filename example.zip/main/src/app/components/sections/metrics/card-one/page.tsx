"use client";

import MetricCardOne from "@/components/sections/metrics/MetricCardOne";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { TrendingUp, Users, DollarSign } from "lucide-react";

export default function MetricCardOnePage() {
    const metrics = [
        {
            id: "1",
            value: "100",
            title: "million",
            description: "Based on feedback from over 10,000 customers worldwide",
            icon: TrendingUp,
        },
        {
            id: "2",
            value: "700",
            title: "thousand",
            description: "Growing community of developers and designers",
            icon: Users,
        },
        {
            id: "3",
            value: "100",
            title: "projects",
            description: "Helping businesses grow their bottom line",
            icon: DollarSign,
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <div className="min-h-screen p-8">
                <MetricCardOne
                    metrics={metrics}
                    title="Our Impact"
                    description="Key metrics that showcase our growth"
          gridVariant="uniform-all-items-equal"
                textboxLayout="default"
                
                animationType="slide-up"
            />
            </div>
        </ThemeProvider>
    );
}
