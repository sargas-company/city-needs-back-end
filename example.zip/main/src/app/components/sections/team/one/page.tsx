"use client";

import TeamCardOne from "@/components/sections/team/TeamCardOne";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function TeamOnePage() {
    const members = [
        {
            id: "1",
            name: "Sophie P.",
            role: "Digital Nomad",
            imageSrc: "/placeholders/placeholder3.avif",
            imageAlt: "Sophie P.",
        },
        {
            id: "2",
            name: "John Smith",
            role: "CTO",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "John Smith",
        },
        {
            id: "3",
            name: "Sarah Johnson",
            role: "Head of Design",
            imageSrc: "/placeholders/placeholder3.avif",
            imageAlt: "Sarah Johnson",
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <div className="min-h-screen p-8">
                <TeamCardOne
                    members={members}
                    title="Meet Our Team"
                    description="Get to know the people behind our success"
          gridVariant="uniform-all-items-equal"
                textboxLayout="default"
                
                animationType="slide-up"
            />
            </div>
        </ThemeProvider>
    );
}
