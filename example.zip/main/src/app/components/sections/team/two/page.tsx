"use client";

import TeamCardTwo from "@/components/sections/team/TeamCardTwo";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Twitter, Linkedin, Globe } from "lucide-react";

export default function TeamTwoPage() {
    const members = [
        {
            id: "1",
            name: "Alisa Hester",
            role: "Founder & CEO",
            description: "Former co-founder of Opendoor. Early staff at Spotify and Clearbit. Early staff at Spotify.",
            imageSrc: "/placeholders/placeholder3.avif",
            imageAlt: "Alisa Hester",
            socialLinks: [
                { icon: Twitter, url: "https://twitter.com" },
                { icon: Linkedin, url: "https://linkedin.com" },
                { icon: Globe, url: "https://example.com" },
            ],
        },
        {
            id: "2",
            name: "John Smith",
            role: "CTO",
            description: "Former co-founder of Opendoor. Early staff at Spotify and Clearbit. Early staff at Spotify.",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "John Smith",
            socialLinks: [
                { icon: Twitter, url: "https://twitter.com" },
                { icon: Linkedin, url: "https://linkedin.com" },
            ],
        },
        {
            id: "3",
            name: "Sarah Johnson",
            role: "Head of Design",
            description: "Former co-founder of Opendoor. Early staff at Spotify and Clearbit. Early staff at Spotify.",
            imageSrc: "/placeholders/placeholder3.avif",
            imageAlt: "Sarah Johnson",
            socialLinks: [
                { icon: Linkedin, url: "https://linkedin.com" },
                { icon: Globe, url: "https://example.com" },
            ],
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <div className="min-h-screen p-8">
                <TeamCardTwo
                    members={members}
                    title="Meet Our Team"
                    description="Get to know the people behind our success"
          gridVariant="uniform-all-items-equal"
                textboxLayout="default"
                
                animationType="slide-up"
            />
            </div>
        </ThemeProvider>
    );
}
