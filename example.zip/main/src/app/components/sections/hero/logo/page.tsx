"use client";
import ReactLenis from "lenis/react";
import HeroLogo from "@/components/sections/hero/HeroLogo";
import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function HeroLogoPage() {
    const navItems = [
        { name: "Home", id: "home" },
        { name: "About", id: "about" },
        { name: "Services", id: "services" },
        { name: "Contact", id: "contact" },
    ];

    return (
        <ThemeProvider defaultButtonVariant="hover-bubble" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="animatedAurora" cardStyle="layered-gradient" primaryButtonStyle="diagonal-gradient" secondaryButtonStyle="radial-glow">
            <ReactLenis root>
            <NavbarLayoutFloatingOverlay
                navItems={navItems}
                brandName="Webild"
                button={{ text: "Get Started", onClick: () => console.log("Nav button clicked") }}
            />
            <HeroLogo
                logoText="Webild"
                description="Building the future of web design with innovative solutions"
                buttons={[
                    {
                        text: "Get Started",
                        href: "https://github.com",
                    },
                    {
                        text: "Learn More",
                        href: "about",
                    },
                ]}
                imageSrc="/placeholders/placeholder5.jpg"
                imageAlt="Hero background"
            />
            <div id="about" className="h-screen flex items-center justify-center bg-card">
                <div className="text-center">
                    <h2 className="text-4xl font-bold mb-4">About Section</h2>
                    <p className="text-lg text-muted-foreground">Scroll down to see more content</p>
                </div>
            </div>
            </ReactLenis>
        </ThemeProvider>
    );
}
