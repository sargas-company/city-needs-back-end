"use client";
import ReactLenis from "lenis/react";
import HeroSplit from "@/components/sections/hero/HeroSplit";
import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Sparkles } from "lucide-react";

export default function HeroSplitPage() {
    const navItems = [
        { name: "Home", id: "home" },
        { name: "About", id: "about" },
        { name: "Services", id: "services" },
        { name: "Contact", id: "contact" },
    ];

    return (
        <ThemeProvider defaultButtonVariant="icon-arrow" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="animatedGrid" cardStyle="glass-flat" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
            <NavbarLayoutFloatingOverlay
                navItems={navItems}
                brandName="Webild"
                button={{ text: "Get Started", onClick: () => console.log("Nav button clicked") }}
            />
            <HeroSplit
                tag="New Release Of Our Course"
                tagIcon={Sparkles}
                title="Build Modern Web Experiences"
                description="Create stunning, responsive websites with our comprehensive component library designed"
                buttons={[
                    {
                        text: "Get Started",
                        href: "https://github.com",
                    },
                    {
                        text: "Learn More",
                        href: "about",
                    },
                ]}
                imageSrc="/placeholders/placeholder2.jpg"
                imageAlt="Hero banner"
                imagePosition="right"
                avatars={[
                    { src: "/placeholders/placeholder1.webp", alt: "User 1" },
                    { src: "/placeholders/placeholder2.jpg", alt: "User 2" },
                    { src: "/placeholders/placeholder3.avif", alt: "User 3" },
                    { src: "/placeholders/placeholder4.webp", alt: "User 4" },
                    { src: "/placeholders/placeholder5.jpg", alt: "User 5" },
                    { src: "/placeholders/placeholder3.avif", alt: "User 3" },
                    { src: "/placeholders/placeholder4.webp", alt: "User 4" },
                    { src: "/placeholders/placeholder5.jpg", alt: "User 5" },
                ]}
                avatarText="Join 1,000+ members"
            />
            <div id="about" className="h-screen flex items-center justify-center bg-card">
                <div className="text-center">
                    <h2 className="text-4xl font-bold mb-4">About Section</h2>
                    <p className="text-lg text-muted-foreground">This section demonstrates the scroll-to functionality when clicking "Learn More"</p>
                </div>
            </div>
            </ReactLenis>
        </ThemeProvider>
    );
}
