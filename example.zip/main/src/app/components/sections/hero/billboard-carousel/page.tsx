"use client";
import ReactLenis from "lenis/react";
import HeroBillboardCarousel from "@/components/sections/hero/HeroBillboardCarousel";
import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Sparkles } from "lucide-react";

export default function HeroBillboardCarouselPage() {
    const navItems = [
        { name: "Home", id: "home" },
        { name: "About", id: "about" },
        { name: "Services", id: "services" },
        { name: "Contact", id: "contact" },
    ];

    return (
        <ThemeProvider defaultButtonVariant="hover-bubble" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="animatedAurora" cardStyle="layered-gradient" primaryButtonStyle="diagonal-gradient" secondaryButtonStyle="radial-glow">
            <ReactLenis root>
            <NavbarLayoutFloatingOverlay
                navItems={navItems}
                brandName="Webild"
                button={{ text: "Get Started", onClick: () => console.log("Nav button clicked") }}
            />
            <HeroBillboardCarousel
                tag="Our Portfolio"
                tagIcon={Sparkles}
                title="Browse Our Collection"
                description="Explore our extensive portfolio of projects and creative works"
                buttons={[
                    {
                        text: "View Portfolio",
                        onClick: () => console.log("View Portfolio clicked"),
                    },
                    {
                        text: "Contact Us",
                        onClick: () => console.log("Contact Us clicked"),
                    },
                ]}
                mediaItems={[
                    { imageSrc: "/placeholders/placeholder1.webp", imageAlt: "Product 1" },
                    { imageSrc: "/placeholders/placeholder2.jpg", imageAlt: "Product 2" },
                    { imageSrc: "/placeholders/placeholder3.avif", imageAlt: "Product 3" },
                    { imageSrc: "/placeholders/placeholder4.webp", imageAlt: "Product 4" },
                    { imageSrc: "/placeholders/placeholder2.jpg", imageAlt: "Product 5" },
                    { imageSrc: "/placeholders/placeholder1.webp", imageAlt: "Product 6" },
                    { imageSrc: "/placeholders/placeholder3.avif", imageAlt: "Product 7" },
                ]}
            />
            </ReactLenis>
        </ThemeProvider>
    );
}
