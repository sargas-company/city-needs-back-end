import ReactLenis from "lenis/react";
import Link from "next/link";

export default function HeroSectionsPage() {
    const heroComponents = [
        {
            title: "Hero Billboard",
            href: "/components/sections/hero/billboard",
        },
        {
            title: "Hero Billboard Gallery",
            href: "/components/sections/hero/billboard-gallery",
        },
        {
            title: "Hero Billboard Carousel",
            href: "/components/sections/hero/billboard-carousel",
        },
        {
            title: "Hero Billboard Corners",
            href: "/components/sections/hero/billboard-corners",
        },
        {
            title: "Hero Billboard Scroll",
            href: "/components/sections/hero/billboard-scroll",
        },
        {
            title: "Hero Split",
            href: "/components/sections/hero/split",
        },
        {
            title: "Hero Split Stacked",
            href: "/components/sections/hero/split-stacked",
        },
        {
            title: "Hero Overlay",
            href: "/components/sections/hero/overlay",
        },
        {
            title: "Hero Logo",
            href: "/components/sections/hero/logo",
        },
        {
            title: "Hero Carousel Logo",
            href: "/components/sections/hero/carousel-logo",
        },
    ];

    return (
        <ReactLenis root>
            <section className="min-h-screen py-[var(--width-10)]">
                <div className="w-full px-[var(--width-10)]">
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                        {heroComponents.map((component) => (
                            <Link key={component.href} href={component.href}>
                                <div className="aspect-square tag-card relative rounded p-6 flex justify-center items-center text-center cursor-pointer">
                                    <h3 className="text-xl font-normal text-black">{component.title}</h3>
                                </div>
                            </Link>
                        ))}
                    </div>
                </div>
            </section>
        </ReactLenis>
    );
}
