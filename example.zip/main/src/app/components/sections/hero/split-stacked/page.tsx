"use client";
import ReactLenis from "lenis/react";
import HeroSplitStacked from "@/components/sections/hero/HeroSplitStacked";
import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Sparkles } from "lucide-react";

export default function HeroSplitStackedPage() {
    const navItems = [
        { name: "Home", id: "home" },
        { name: "About", id: "about" },
        { name: "Services", id: "services" },
        { name: "Contact", id: "contact" },
    ];

    return (
        <ThemeProvider defaultButtonVariant="icon-arrow" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="animatedGrid" cardStyle="glass-flat" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
            <NavbarLayoutFloatingOverlay
                navItems={navItems}
                brandName="Webild"
                button={{ text: "Get Started", onClick: () => console.log("Nav button clicked") }}
            />
            <HeroSplitStacked
                tag="Featured Gallery"
                tagIcon={Sparkles}
                title="Explore Our Collection"
                description="Discover stunning visuals and creative designs in our curated collection"
                buttons={[
                    {
                        text: "View Gallery",
                        onClick: () => console.log("View Gallery clicked"),
                    },
                    {
                        text: "Learn More",
                        href: "about",
                    },
                ]}
                mediaItems={[
                    { imageSrc: "/placeholders/placeholder1.webp", imageAlt: "Gallery 1" },
                    { imageSrc: "/placeholders/placeholder2.jpg", imageAlt: "Gallery 2" },
                    { imageSrc: "/placeholders/placeholder3.avif", imageAlt: "Gallery 3" },
                    { imageSrc: "/placeholders/placeholder4.webp", imageAlt: "Gallery 4" },
                ]}
                // stackedVariant="card"
                imagePosition="right"
            />
            <div id="about" className="h-screen flex items-center justify-center bg-card">
                <div className="text-center">
                    <h2 className="text-4xl font-bold mb-4">About Section</h2>
                    <p className="text-lg text-muted-foreground">This section demonstrates the scroll-to functionality when clicking "Learn More"</p>
                </div>
            </div>
            </ReactLenis>
        </ThemeProvider>
    );
}
