"use client";
import ReactLenis from "lenis/react";
import HeroBillboardScroll from "@/components/sections/hero/HeroBillboardScroll";
import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Sparkles } from "lucide-react";

export default function HeroBillboardScrollPage() {
    const navItems = [
        { name: "Home", id: "home" },
        { name: "About", id: "about" },
        { name: "Services", id: "services" },
        { name: "Contact", id: "contact" },
    ];

    return (
        <ThemeProvider defaultButtonVariant="hover-bubble" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="animatedAurora" cardStyle="layered-gradient" primaryButtonStyle="diagonal-gradient" secondaryButtonStyle="radial-glow">
            <ReactLenis root>
            <NavbarLayoutFloatingOverlay
                navItems={navItems}
                brandName="Webild"
                button={{ text: "Get Started", onClick: () => console.log("Nav button clicked") }}
            />
            <HeroBillboardScroll
                tag="Unleash the Power"
                tagIcon={Sparkles}
                title="Scroll Animations"
                description="Experience smooth, performant animations as you scroll through your content"
                buttons={[
                    {
                        text: "Get Started",
                        onClick: () => console.log("Get Started clicked"),
                    },
                    {
                        text: "Learn More",
                        href: "about",
                    },
                ]}
                imageSrc="/placeholders/placeholder1.webp"
                imageAlt="Hero showcase"
            />
            <div id="about" className="h-screen flex items-center justify-center bg-card">
                <div className="text-center">
                    <h2 className="text-4xl font-bold mb-4">About Section</h2>
                    <p className="text-lg text-muted-foreground">Scroll back up to see the reverse animation effect</p>
                </div>
            </div>
            </ReactLenis>
        </ThemeProvider>
    );
}
