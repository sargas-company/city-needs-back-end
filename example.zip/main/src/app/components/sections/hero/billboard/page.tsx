"use client";
import ReactLenis from "lenis/react";
import HeroBillboard from "@/components/sections/hero/HeroBillboard";
import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Sparkles } from "lucide-react";

export default function HeroBillboardPage() {
    const navItems = [
        { name: "Home", id: "home" },
        { name: "About", id: "about" },
        { name: "Services", id: "services" },
        { name: "Contact", id: "contact" },
    ];

    return (
        <ThemeProvider defaultButtonVariant="hover-bubble" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="animatedAurora" cardStyle="layered-gradient" primaryButtonStyle="diagonal-gradient" secondaryButtonStyle="radial-glow">
            <ReactLenis root>
            <NavbarLayoutFloatingOverlay
                navItems={navItems}
                brandName="Webild"
                button={{ text: "Get Started", onClick: () => console.log("Nav button clicked") }}
            />
            <HeroBillboard
                tag="New Release Of Our Course"
                tagIcon={Sparkles}
                title="Build Modern Web Experiences"
                description="Create stunning, responsive websites with our comprehensive component library designed"
                buttons={[
                    {
                        text: "Get Started",
                        onClick: () => console.log("Get Started clicked"),
                    },
                    {
                        text: "Learn More",
                        onClick: () => console.log("Learn More clicked"),
                    },
                ]}
                imageSrc="/placeholders/placeholder2.jpg"
                imageAlt="Hero banner"
                frameStyle="browser"
            />
            </ReactLenis>
        </ThemeProvider>
    );
}