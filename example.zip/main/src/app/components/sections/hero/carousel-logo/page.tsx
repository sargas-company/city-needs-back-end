"use client";

import ReactLenis from "lenis/react";
import HeroCarouselLogo from "@/components/sections/hero/heroCarouselLogo/HeroCarouselLogo";
import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function HeroCarouselLogoPage() {
  const navItems = [
    { name: "Home", id: "home" },
    { name: "About", id: "about" },
    { name: "Services", id: "services" },
    { name: "Contact", id: "contact" },
  ];

  const slides = [
    {
      imageSrc: "/placeholders/placeholder1.webp",
      imageAlt: "Slide 1",
    },
    {
      imageSrc: "/placeholders/placeholder2.jpg",
      imageAlt: "Slide 2",
    },
    {
      imageSrc: "/placeholders/placeholder3.avif",
      imageAlt: "Slide 3",
    },
    {
      imageSrc: "/placeholders/placeholder4.webp",
      imageAlt: "Slide 4",
    },
  ];

  return (
    <ThemeProvider
      defaultButtonVariant="icon-arrow"
      defaultTextAnimation="entrance-slide"
      borderRadius="pill"
      contentWidth="medium"
      sizing="medium"
      background="none"
      cardStyle="glass-flat"
      primaryButtonStyle="gradient"
      secondaryButtonStyle="glass"
    >
      <ReactLenis root>
        <NavbarLayoutFloatingOverlay
          navItems={navItems}
          brandName="Webild"
          button={{
            text: "Get Started",
            onClick: () => console.log("Nav button clicked"),
          }}
        />
        <HeroCarouselLogo
          logoText="WEBILD"
          description="Create stunning, responsive websites with our comprehensive component library designed for developers and designers"
          buttons={[
            {
              text: "Get Started",
              href: "https://github.com",
            },
            {
              text: "Learn More",
              href: "about",
            },
          ]}
          slides={slides}
          autoplayDelay={5000}
        />
        <div
          id="about"
          className="h-screen flex items-center justify-center bg-card"
        >
          <div className="text-center">
            <h2 className="text-4xl font-bold mb-4">About Section</h2>
            <p className="text-lg text-muted-foreground">
              This section demonstrates the scroll-to functionality when clicking
              "Learn More"
            </p>
          </div>
        </div>
      </ReactLenis>
    </ThemeProvider>
  );
}
