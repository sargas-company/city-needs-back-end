"use client";
import ReactLenis from "lenis/react";
import HeroBillboardCorners from "@/components/sections/hero/HeroBillboardCorners";
import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Sparkles } from "lucide-react";

export default function HeroBillboardCornersPage() {
    const navItems = [
        { name: "Home", id: "home" },
        { name: "About", id: "about" },
        { name: "Services", id: "services" },
        { name: "Contact", id: "contact" },
    ];

    return (
        <ThemeProvider defaultButtonVariant="hover-bubble" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="animatedAurora" cardStyle="layered-gradient" primaryButtonStyle="diagonal-gradient" secondaryButtonStyle="radial-glow">
            <ReactLenis root>
            <NavbarLayoutFloatingOverlay
                navItems={navItems}
                brandName="Webild"
                button={{ text: "Get Started", onClick: () => console.log("Nav button clicked") }}
            />
            <HeroBillboardCorners
                tag="Meet the Future"
                tagIcon={Sparkles}
                title="Where education meets automation"
                description="A revolutionary classroom with automated attendance, resource tracking, and performance analysis tools"
                buttons={[
                    {
                        text: "Register",
                        onClick: () => console.log("Register clicked"),
                    },
                    {
                        text: "Know More",
                        href: "about",
                    },
                ]}
                mediaItems={[
                    { imageSrc: "/placeholders/placeholder1.webp", imageAlt: "Student 1" },
                    { imageSrc: "/placeholders/placeholder2.jpg", imageAlt: "Student 2" },
                    { imageSrc: "/placeholders/placeholder3.avif", imageAlt: "Learning materials" },
                    { imageSrc: "/placeholders/placeholder4.webp", imageAlt: "Student 3" },
                ]}
            />
            <div id="about" className="h-screen flex items-center justify-center bg-card">
                <div className="text-center">
                    <h2 className="text-4xl font-bold mb-4">About Section</h2>
                    <p className="text-lg text-muted-foreground">This section demonstrates the scroll-to functionality when clicking "Know More"</p>
                </div>
            </div>
            </ReactLenis>
        </ThemeProvider>
    );
}
