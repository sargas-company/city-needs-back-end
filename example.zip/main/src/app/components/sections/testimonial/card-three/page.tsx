"use client";

import TestimonialCardThree from "@/components/sections/testimonial/TestimonialCardThree";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Package } from "lucide-react";

export default function TestimonialCardThreePage() {
    const testimonials = [
        {
            id: "1",
            name: "Jack",
            handle: "@jack",
            testimonial: "I've never seen anything like this before. It's amazing. I love it.",
            icon: Package,
        },
        {
            id: "2",
            name: "Sarah",
            handle: "@sarahj",
            testimonial: "The quality and attention to detail is outstanding. Highly recommended!",
            imageSrc: "/placeholders/placeholder3.avif",
            imageAlt: "Sarah",
        },
        {
            id: "3",
            name: "Mike",
            handle: "@mike_tech",
            testimonial: "Game changer for our business. The team delivered beyond expectations.",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "Mike",
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <div className="min-h-screen p-8">
                <TestimonialCardThree
                    testimonials={testimonials}
                    title="What Our Clients Say"
                    description="Hear from those who've experienced our work"
                textboxLayout="default"
                
                animationType="slide-up"
            />
            </div>
        </ThemeProvider>
    );
}
