"use client";

import ReactLenis from "lenis/react";
import TestimonialCardFour from "@/components/sections/testimonial/TestimonialCardFour";
import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function TestimonialCardFourPage() {
    const navItems = [
        { name: "Home", id: "home" },
        { name: "About", id: "about" },
        { name: "Services", id: "services" },
        { name: "Contact", id: "contact" },
    ];

    const testimonials = [
        {
            id: "1",
            name: "Alisa Hester",
            role: "PM, Hourglass",
            company: "Web Design Agency",
            rating: 5,
            imageSrc: "/placeholderS/placeholder5.jpg",
        },
        {
            id: "2",
            name: "John Smith",
            role: "CTO",
            company: "Tech Solutions Inc",
            rating: 5,
            imageSrc: "/placeholderS/placeholder2.jpg",
        },
        {
            id: "3",
            name: "Sarah Johnson",
            role: "Lead Designer",
            company: "Creative Studio",
            rating: 4,
            imageSrc: "/placeholderS/placeholder3.avif",
        },
        {
            id: "4",
            name: "Michael Chen",
            role: "Founder",
            company: "Startup Inc",
            rating: 5,
            imageSrc: "/placeholderS/placeholder4.jpg",
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="layered-gradient" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <NavbarLayoutFloatingOverlay
                    navItems={navItems}
                    brandName="Webild"
                    button={{ text: "Get Started", onClick: () => console.log("Nav button clicked") }}
                />
                <TestimonialCardFour
                    testimonials={testimonials}
                    title="What Our Clients Say"
                    description="Hear from those who've experienced our work"
                    textboxLayout="default"
                />
            </ReactLenis>
        </ThemeProvider>
    );
}
