"use client";

import TestimonialCardOne from "@/components/sections/testimonial/TestimonialCardOne";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function TestimonialCardOnePage() {
    const testimonials = [
        {
            id: "1",
            name: "Alisa Hester",
            role: "PM, Hourglass",
            company: "Web Design Agency",
            rating: 5,
            imageSrc: "/placeholders/placeholder3.avif",
            imageAlt: "Alisa Hester",
        },
        {
            id: "2",
            name: "John Smith",
            role: "CTO",
            company: "Tech Solutions Inc",
            rating: 5,
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "John Smith",
        },
        {
            id: "3",
            name: "Sarah Johnson",
            role: "Designer",
            company: "Creative Studio",
            rating: 4,
            imageSrc: "/placeholders/placeholder3.avif",
            imageAlt: "Sarah Johnson",
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <div className="min-h-screen p-8">
                <TestimonialCardOne
                    testimonials={testimonials}
                    title="What Our Clients Say"
                    description="Hear from those who've experienced our work"
                    textboxLayout="default"
                    gridVariant="uniform-all-items-equal"
                    animationType="slide-up"
                />
            </div>
        </ThemeProvider>
    );
}
