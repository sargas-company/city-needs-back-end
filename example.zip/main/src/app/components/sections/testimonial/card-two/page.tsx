"use client";

import TestimonialCardTwo from "@/components/sections/testimonial/TestimonialCardTwo";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Package } from "lucide-react";

export default function TestimonialCardTwoPage() {
    const testimonials = [
        {
            id: "1",
            name: "Kris Kellaway",
            role: "President of Kinimatic",
            testimonial: "We're blown away by the precision and care Dialedweb brought to our project. Their team truly listened, collaborated seamlessly, and delivered a website that far exceeded our expectations.",
            icon: Package,
        },
        {
            id: "2",
            name: "Sarah Johnson",
            role: "CTO, Tech Solutions",
            testimonial: "The attention to detail and commitment to excellence was outstanding. Every aspect of our project was handled with care and professionalism.",
            imageSrc: "/placeholders/placeholder3.avif",
            imageAlt: "Sarah Johnson",
        },
        {
            id: "3",
            name: "John Smith",
            role: "Marketing Director",
            testimonial: "Working with this team was a game-changer for our business. They understood our vision and brought it to life beyond what we imagined.",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "John Smith",
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <div className="min-h-screen p-8">
                <TestimonialCardTwo
                    testimonials={testimonials}
                    title="What Our Clients Say"
                    description="Hear from those who've experienced our work"
                textboxLayout="default"
                
                animationType="slide-up"
            />
            </div>
        </ThemeProvider>
    );
}
