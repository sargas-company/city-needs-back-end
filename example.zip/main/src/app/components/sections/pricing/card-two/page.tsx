"use client";

import PricingCardTwo from "@/components/sections/pricing/PricingCardTwo";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Sparkles } from "lucide-react";

export default function PricingCardTwoPage() {
    const plans = [
        {
            id: "1",
            badge: "Basic plan",
            price: "$10/mth",
            subtitle: "Our most popular plan.",
            buttons: [
                {
                    text: "Get started",
                    onClick: () => console.log("Get started clicked"),
                },
                {
                    text: "Chat to sales",
                    onClick: () => console.log("Chat to sales clicked"),
                },
            ],
            features: [
                "Access to all basic features",
                "Basic reporting and analytics",
                "Up to 10 individual users",
                "20 GB individual data",
                "Basic chat and email support",
            ],
        },
        {
            id: "2",
            badge: "Business plan",
            badgeIcon: Sparkles,
            price: "$20/mth",
            subtitle: "Advanced features for teams.",
            buttons: [
                {
                    text: "Get started",
                    onClick: () => console.log("Get started clicked"),
                },
                {
                    text: "Chat to sales",
                    onClick: () => console.log("Chat to sales clicked"),
                },
            ],
            features: [
                "Access to all advanced features",
                "Advanced reporting and analytics",
                "Up to 50 individual users",
                "100 GB individual data",
                "Priority chat and email support"
            ],
        },
        {
            id: "3",
            badge: "Enterprise",
            price: "$40/mth",
            subtitle: "For large organizations.",
            buttons: [
                {
                    text: "Get started",
                    onClick: () => console.log("Get started clicked"),
                },
                {
                    text: "Chat to sales",
                    onClick: () => console.log("Chat to sales clicked"),
                },
            ],
            features: [
                "Access to all enterprise features",
                "Custom reporting and analytics",
                "Unlimited individual users",
                "Unlimited individual data",
                "24/7 phone and email support"
            ],
        },
        {
            id: "3",
            badge: "Enterprise",
            price: "$40/mth",
            subtitle: "For large organizations.",
            buttons: [
                {
                    text: "Get started",
                    onClick: () => console.log("Get started clicked"),
                },
                {
                    text: "Chat to sales",
                    onClick: () => console.log("Chat to sales clicked"),
                },
            ],
            features: [
                "Access to all enterprise features",
                "Custom reporting and analytics",
                "Unlimited individual users",
                "Unlimited individual data",
                "24/7 phone and email support"
            ],
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="rounded" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <div className="min-h-screen p-8">
                <PricingCardTwo
                    plans={plans}
                    title="Choose Your Plan"
                    description="Select the perfect plan for your needs"
                    textboxLayout="default"
                
                animationType="slide-up"
            />
            </div>
        </ThemeProvider>
    );
}
