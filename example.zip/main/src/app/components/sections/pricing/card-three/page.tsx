"use client";

import PricingCardThree from "@/components/sections/pricing/PricingCardThree";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Sparkles } from "lucide-react";

export default function PricingCardThreePage() {
    const plans = [
        {
            id: "1",
            price: "$10/mth",
            name: "Basic plan",
            description: "Our most popular plan.",
            buttons: [
                {
                    text: "Get started",
                    onClick: () => console.log("Get started clicked"),
                },
                {
                    text: "Chat to sales",
                    onClick: () => console.log("Chat to sales clicked"),
                },
            ],
            features: [
                "Access to all basic features",
                "Basic reporting and analytics",
                "Up to 10 individual users",
                "20 GB individual data",
                "Basic chat and email support",
            ],
        },
        {
            id: "2",
            badge: "Most popular plan",
            badgeIcon: Sparkles,
            price: "$20/mth",
            name: "Business plan",
            description: "Growing teams up to 20 users.",
            buttons: [
                {
                    text: "Get started",
                    onClick: () => console.log("Get started clicked"),
                },
                {
                    text: "Chat to sales",
                    onClick: () => console.log("Chat to sales clicked"),
                },
            ],
            features: [
                "200+ integrations",
                "Advanced reporting and analytics",
                "Up to 20 individual users",
                "40 GB individual data",
                "Priority chat and email support"
            ],
        },
        {
            id: "3",
            price: "$40/mth",
            name: "Enterprise plan",
            description: "Advanced features + unlimited users.",
            buttons: [
                {
                    text: "Get started",
                    onClick: () => console.log("Get started clicked"),
                },
                {
                    text: "Chat to sales",
                    onClick: () => console.log("Chat to sales clicked"),
                },
            ],
            features: [
                "Advanced custom fields",
                "Audit log and data history",
                "Unlimited individual users",
                "Unlimited individual data",
                "Personalized + priority service"
            ],
        },
        {
            id: "3",
            price: "$40/mth",
            name: "Enterprise plan",
            description: "Advanced features + unlimited users.",
            buttons: [
                {
                    text: "Get started",
                    onClick: () => console.log("Get started clicked"),
                },
                {
                    text: "Chat to sales",
                    onClick: () => console.log("Chat to sales clicked"),
                },
            ],
            features: [
                "Advanced custom fields",
                "Audit log and data history",
                "Unlimited individual users",
                "Unlimited individual data",
                "Personalized + priority service"
            ],
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <div className="min-h-screen p-8">
                <PricingCardThree
                    plans={plans}
                    title="Choose Your Plan"
                    description="Select the perfect plan for your needs"
                    textboxLayout="default"
                
                animationType="slide-up"
            />
            </div>
        </ThemeProvider>
    );
}
