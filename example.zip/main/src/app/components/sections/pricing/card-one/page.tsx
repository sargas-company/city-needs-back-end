"use client";

import PricingCardOne from "@/components/sections/pricing/PricingCardOne";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Sparkles } from "lucide-react";

export default function PricingCardOnePage() {
    const plans = [
        {
            id: "1",
            badge: "Most Popular",
            badgeIcon: Sparkles,
            price: "$29/mo",
            subtitle: "Perfect for small teams",
            features: [
                "Up to 10 team members",
                "100GB storage",
                "Priority email support",
                "Advanced analytics",
                "Custom integrations",
            ],
        },
        {
            id: "2",
            badge: "Enterprise",
            price: "$99/mo",
            subtitle: "For growing businesses",
            features: [
                "Unlimited team members",
                "1TB storage",
                "24/7 phone support",
                "Advanced analytics",
                "Custom integrations",
                "Dedicated account manager",
            ],
        },
        {
            id: "3",
            badge: "Starter",
            price: "$9/mo",
            subtitle: "For individuals",
            features: [
                "Up to 3 team members",
                "10GB storage",
                "Email support",
                "Basic analytics",
            ],
        },
        {
            id: "4",
            badge: "Best Value",
            price: "$49/mo",
            subtitle: "For medium teams",
            features: [
                "Up to 25 team members",
                "500GB storage",
                "Priority support",
                "Advanced analytics",
                "Custom integrations",
            ],
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="rounded" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <div className="min-h-screen p-8">
                <PricingCardOne
                    plans={plans}
                    title="Choose Your Plan"
                    description="Select the perfect plan for your needs"
                    textboxLayout="default"
                
                animationType="slide-up"
            />
            </div>
        </ThemeProvider>
    );
}
