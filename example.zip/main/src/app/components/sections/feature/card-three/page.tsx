"use client";
import ReactLenis from "lenis/react";
import FeatureCardThree from "@/components/sections/feature/featureCardThree/FeatureCardThree";
import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function FeatureCardThreePage() {
    const navItems = [
        { name: "Home", id: "home" },
        { name: "About", id: "about" },
        { name: "Services", id: "services" },
        { name: "Contact", id: "contact" },
    ];

    const features = [
        {
            id: "01",
            title: "Advanced Analytics",
            description: "Get detailed insights into your business performance with our powerful analytics tools.",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "Analytics dashboard"
        },
        {
            id: "02",
            title: "Team Collaboration",
            description: "Work seamlessly with your team using real-time collaboration tools and shared workspaces.",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "Team collaboration"
        },
        {
            id: "03",
            title: "Cloud Storage",
            description: "Store and access your files securely from anywhere with unlimited cloud storage.",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "Cloud storage"
        },
        {
            id: "04",
            title: "Mobile App",
            description: "Stay connected on the go with our native mobile apps for iOS and Android.",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "Mobile application"
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
            <NavbarLayoutFloatingOverlay
                navItems={navItems}
                brandName="Webild"
                button={{ text: "Get Started", onClick: () => console.log("Nav button clicked") }}
            />
            <FeatureCardThree
                title="Our Features"
                description="Discover what makes us different"
          gridVariant="uniform-all-items-equal"
                textboxLayout="default"
                // tag="Features"
                features={features}
                // buttons={[
                //     { text: "Get Started", href: "#" },
                //     { text: "Learn More", href: "#" }
                // ]}
                carouselMode="buttons"
            
                animationType="slide-up"
            />
            </ReactLenis>
        </ThemeProvider>
    );
}
