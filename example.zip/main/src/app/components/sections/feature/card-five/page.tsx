"use client";
import ReactLenis from "lenis/react";
import FeatureCardFive from "@/components/sections/feature/FeatureCardFive";
import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Zap, Users, Cloud, Smartphone } from "lucide-react";

export default function FeatureCardFivePage() {
    const navItems = [
        { name: "Home", id: "home" },
        { name: "About", id: "about" },
        { name: "Services", id: "services" },
        { name: "Contact", id: "contact" },
    ];

    const features = [
        {
            title: "Advanced Analytics",
            icon: Zap,
        },
        {
            title: "Team Collaboration",
            icon: Users,
        },
        {
            title: "Cloud Storage",
            icon: Cloud,
        },
        {
            title: "Mobile App",
            icon: Smartphone,
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="layered-gradient" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <NavbarLayoutFloatingOverlay
                    navItems={navItems}
                    brandName="Webild"
                    button={{ text: "Get Started", onClick: () => console.log("Nav button clicked") }}
                />
                <FeatureCardFive
                    title="Our Features"
                    description="Discover what makes us different"
                    gridVariant="uniform-all-items-equal"
                    // gridVariant="two-columns-alternating-heights"
                    // gridVariant="asymmetric-60-wide-40-narrow"
                    // gridVariant="three-columns-all-equal-width"
                    // gridVariant="four-items-2x2-equal-grid"
                    // gridVariant="one-large-right-three-stacked-left"
                    // gridVariant="items-top-row-full-width-bottom"
                    // gridVariant="full-width-top-items-bottom-row"
                    // gridVariant="one-large-left-three-stacked-right"
                    textboxLayout="default"
                    // tag="Features"
                    features={features}
                    // buttons={[
                    //     { text: "Get Started", href: "#" },
                    //     { text: "Learn More", href: "#" }
                    // ]}
                    carouselMode="buttons"
                
                animationType="slide-up"
            />
            </ReactLenis>
        </ThemeProvider>
    );
}
