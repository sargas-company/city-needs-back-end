import ReactLenis from "lenis/react";
import Link from "next/link";

export default function FeatureSectionsPage() {
    const featureComponents = [
        {
            title: "Feature Card One",
            href: "/components/sections/feature/card-one",
        },
        {
            title: "Feature Card Two",
            href: "/components/sections/feature/card-two",
        },
        {
            title: "Feature Card Three",
            href: "/components/sections/feature/card-three",
        },
        {
            title: "Feature Card Four",
            href: "/components/sections/feature/card-four",
        },
        {
            title: "Feature Card Five",
            href: "/components/sections/feature/card-five",
        },
        {
            title: "Feature Card Six",
            href: "/components/sections/feature/card-six",
        },
        {
            title: "Feature Card Seven",
            href: "/components/sections/feature/card-seven",
        },
        {
            title: "Feature Card Eight",
            href: "/components/sections/feature/card-eight",
        },
        {
            title: "Feature Card Nine",
            href: "/components/sections/feature/card-nine",
        },
        {
            title: "Feature Card Ten",
            href: "/components/sections/feature/card-ten",
        },
    ];

    return (
        <ReactLenis root>
            <section className="min-h-screen py-[var(--width-10)]">
                <div className="w-full px-[var(--width-10)]">
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                        {featureComponents.map((component) => (
                            <Link key={component.href} href={component.href}>
                                <div className="aspect-square tag-card relative rounded p-6 flex justify-center items-center text-center cursor-pointer">
                                    <h3 className="text-xl font-normal text-foreground">{component.title}</h3>
                                </div>
                            </Link>
                        ))}
                    </div>
                </div>
            </section>
        </ReactLenis>
    );
}
