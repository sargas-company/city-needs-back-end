"use client";
import ReactLenis from "lenis/react";
import FeatureCardFour from "@/components/sections/feature/FeatureCardFour";
import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Zap, Users, Cloud, Smartphone } from "lucide-react";

export default function FeatureCardFourPage() {
    const navItems = [
        { name: "Home", id: "home" },
        { name: "About", id: "about" },
        { name: "Services", id: "services" },
        { name: "Contact", id: "contact" },
    ];

    const features = [
        {
            title: "Advanced Analytics",
            description: "Get detailed insights into your business performance with our powerful analytics tools.",
            icon: Zap,
        },
        {
            title: "Team Collaboration",
            description: "Work seamlessly with your team using real-time collaboration tools.",
            icon: Users,
        },
        {
            title: "Cloud Storage",
            description: "Store and access your files securely from anywhere with unlimited cloud storage.",
            icon: Cloud,
        },
        {
            title: "Mobile App",
            description: "Stay connected on the go with our native mobile apps for iOS and Android.",
            icon: Smartphone,
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <NavbarLayoutFloatingOverlay
                    navItems={navItems}
                    brandName="Webild"
                    button={{ text: "Get Started", onClick: () => console.log("Nav button clicked") }}
                />
                <FeatureCardFour
                    title="Our Features"
                    description="Discover what makes us different"
                    textboxLayout="default"
                    // tag="Features"
                    features={features}
                    carouselMode="buttons"
                
                animationType="slide-up"
            />
            </ReactLenis>
        </ThemeProvider>
    );
}
