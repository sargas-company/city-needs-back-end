"use client";

import ReactLenis from "lenis/react";
import FeatureCardNine from "@/components/sections/feature/FeatureCardNine";
import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function FeatureCardNinePage() {
    const navItems = [
        { name: "Home", id: "home" },
        { name: "About", id: "about" },
        { name: "Services", id: "services" },
        { name: "Contact", id: "contact" },
    ];

    const features = [
        {
            id: 1,
            title: "Seamless Integration",
            description: "Connect your tools and workflows effortlessly. Our platform integrates with your existing systems to provide a unified experience.",
            phoneOne: {
                imageSrc: "/placeholders/placeholder2.jpg",
            },
            phoneTwo: {
                imageSrc: "/placeholders/placeholder2.jpg",
            },
        },
        {
            id: 2,
            title: "Real-time Collaboration",
            description: "Work together in real-time with your team. See changes instantly and collaborate without friction across devices.",
            phoneOne: {
                imageSrc: "/placeholders/placeholder2.jpg",
            },
            phoneTwo: {
                imageSrc: "/placeholders/placeholder2.jpg",
            },
        },
        {
            id: 3,
            title: "Powerful Analytics",
            description: "Gain insights from your data with comprehensive analytics. Track performance, identify trends, and make informed decisions.",
            phoneOne: {
                imageSrc: "/placeholders/placeholder2.jpg",
            },
            phoneTwo: {
                imageSrc: "/placeholders/placeholder2.jpg",
            },
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="layered-gradient" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <NavbarLayoutFloatingOverlay
                    navItems={navItems}
                    brandName="Webild"
                    button={{ text: "Get Started", onClick: () => console.log("Nav button clicked") }}
                />
                <section className="relative w-full h-screen flex items-center justify-center" >
                    <p className="text-4xl text-foreground" >scroll</p>
                </section>
                <FeatureCardNine
                    features={features}
                    showStepNumbers={true}
                    title="Powerful Features"
                    description="Everything you need to build amazing products"
                    textboxLayout="default"
                />
            </ReactLenis>
        </ThemeProvider>
    );
}
