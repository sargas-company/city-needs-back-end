"use client";
import ReactLenis from "lenis/react";
import FeatureCardEight from "@/components/sections/feature/FeatureCardEight";
import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function FeatureCardEightPage() {
    const navItems = [
        { name: "Home", id: "home" },
        { name: "About", id: "about" },
        { name: "Services", id: "services" },
        { name: "Contact", id: "contact" },
    ];

    const features = [
        {
            id: 1,
            title: "Research & Planning",
            description: "Understanding user needs, market trends, and project requirements. Defining goals and creating a strategic roadmap for success.",
            imageSrc: "/placeholders/placeholder1.webp",
        },
        {
            id: 2,
            title: "Design & Prototyping",
            description: "Creating wireframes, mockups, and interactive prototypes. User testing and feedback integration to refine the design approach.",
            imageSrc: "/placeholders/placeholder2.jpg",
        },
        {
            id: 3,
            title: "Development & Testing",
            description: "Building the product with clean, scalable code. Rigorous testing and quality assurance to deliver a polished final product.",
            imageSrc: "/placeholders/placeholder3.avif",
        },
        {
            id: 4,
            title: "Launch & Support",
            description: "Deploying the final product and providing ongoing maintenance. Continuous improvement and feature updates based on user feedback.",
            imageSrc: "/placeholders/placeholder4.webp",
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="layered-gradient" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <NavbarLayoutFloatingOverlay
                    navItems={navItems}
                    brandName="Webild"
                    button={{ text: "Get Started", onClick: () => console.log("Nav button clicked") }}
                />
                <FeatureCardEight
                    title="Our Process"
                    description="Discover how we bring ideas to life"
                    textboxLayout="default"
                    features={features}
                />
            </ReactLenis>
        </ThemeProvider>
    );
}
