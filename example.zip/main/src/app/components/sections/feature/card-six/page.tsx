"use client";
import ReactLenis from "lenis/react";
import FeatureCardSix from "@/components/sections/feature/FeatureCardSix";
import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function FeatureCardSixPage() {
    const navItems = [
        { name: "Home", id: "home" },
        { name: "About", id: "about" },
        { name: "Services", id: "services" },
        { name: "Contact", id: "contact" },
    ];

    const features = [
        {
            id: 1,
            title: "Research & Planning",
            description: "Understanding user needs, market trends, and project requirements. Defining goals and creating a strategic roadmap for success.",
            imageSrc: "/placeholderS/placeholder5.jpg",
        },
        {
            id: 2,
            title: "Design & Prototyping",
            description: "Creating wireframes, mockups, and interactive prototypes. User testing and feedback integration to refine the design approach and ensure optimal user experience.",
            imageSrc: "/placeholderS/placeholder2.jpg",
        },
        {
            id: 3,
            title: "Development & Testing",
            description: "Building the product with clean, scalable code. Rigorous testing and quality assurance to deliver a polished final product.",
            imageSrc: "/placeholderS/placeholder3.avif",
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="layered-gradient" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <NavbarLayoutFloatingOverlay
                    navItems={navItems}
                    brandName="Webild"
                    button={{ text: "Get Started", onClick: () => console.log("Nav button clicked") }}
                />
                <FeatureCardSix
                    title="Our Process"
                    description="Discover how we bring ideas to life"
                    textboxLayout="default"
                    features={features}
                />
            </ReactLenis>
        </ThemeProvider>
    );
}
