"use client";

import ReactLenis from "lenis/react";
import FeatureCardTen from "@/components/sections/feature/FeatureCardTen";
import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Check, Zap, Shield } from "lucide-react";

export default function FeatureCardTenPage() {
    const navItems = [
        { name: "Home", id: "home" },
        { name: "About", id: "about" },
        { name: "Services", id: "services" },
        { name: "Contact", id: "contact" },
    ];

    const features = [
        {
            id: "1",
            title: "Seamless Integration",
            description: "Initial research and planning phase for the project development including market analysis, user interviews, competitive research, and technical feasibility studies to ensure project success.",
            media: {
                imageSrc: "/placeholders/placeholder2.jpg",
            },
            items: [
                { icon: Check, text: "One-click integrations" },
                { icon: Zap, text: "Lightning-fast sync" },
                { icon: Shield, text: "Enterprise security" },
            ],
            reverse: false,
        },
        {
            id: "2",
            title: "Real-time Collaboration",
            description: "Initial research and planning phase for the project development including market analysis, user interviews, competitive research, and technical feasibility studies to ensure project success.",
            media: {
                imageSrc: "/placeholders/placeholder2.jpg",
            },
            items: [
                { icon: Check, text: "Instant updates" },
                { icon: Zap, text: "Live presence indicators" },
                { icon: Shield, text: "Conflict resolution" },
            ],
            reverse: true,
        },
        {
            id: "3",
            title: "Powerful Analytics",
            description: "Initial research and planning phase for the project development including market analysis, user interviews, competitive research, and technical feasibility studies to ensure project success.",
            media: {
                imageSrc: "/placeholders/placeholder2.jpg",
            },
            items: [
                { icon: Check, text: "Custom reports" },
                { icon: Zap, text: "Real-time metrics" },
                { icon: Shield, text: "Data privacy" },
            ],
            reverse: false,
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="layered-gradient" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <NavbarLayoutFloatingOverlay
                    navItems={navItems}
                    brandName="Webild"
                    button={{ text: "Get Started", onClick: () => console.log("Nav button clicked") }}
                />
                <section className="relative w-full h-screen flex items-center justify-center" >
                    <p className="text-4xl text-foreground" >scroll</p>
                </section>
                <FeatureCardTen
                    features={features}
                    title="Powerful Features"
                    description="Everything you need to build amazing products"
                    tag="Features"
                    textboxLayout="default"
                    animationType="slide-up"
                />
            </ReactLenis>
        </ThemeProvider>
    );
}
