"use client";
import ReactLenis from "lenis/react";
import FeatureCardOne from "@/components/sections/feature/FeatureCardOne";
import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function FeatureCardOnePage() {
    const navItems = [
        { name: "Home", id: "home" },
        { name: "About", id: "about" },
        { name: "Services", id: "services" },
        { name: "Contact", id: "contact" },
    ];

    const features = [
        {
            title: "Advanced Analytics",
            description: "Get detailed insights into your business performance with our powerful.",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "Analytics dashboard",
            // button: { text: "Learn More", href: "#" }
        },
        {
            title: "Team Collaboration",
            description: "Work seamlessly with your team using real-time collaboration tools and shared workspaces.",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "Team collaboration",
            // button: { text: "Get Started", href: "#" }
        },
        {
            title: "Cloud Storage",
            description: "Store and access your files securely from anywhere with unlimited cloud storage.",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "Cloud storage",
            // button: { text: "View Demo", href: "#" }
        },
        {
            title: "Mobile App",
            description: "Stay connected on the go with our native mobile apps for iOS and Android.",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "Mobile application",
            // button: { text: "Download", href: "#" }
        },
        // {
        //     title: "Cloud Storage",
        //     description: "Store and access your files securely from anywhere with unlimited cloud storage.",
        //     imageSrc: "/placeholders/placeholder4.webp",
        //     imageAlt: "Cloud storage"
        // },
        // {
        //     title: "Mobile App",
        //     description: "Stay connected on the go with our native mobile apps for iOS and Android.",
        //     imageSrc: "/placeholders/placeholder4.webp",
        //     imageAlt: "Mobile application"
        // },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
            <NavbarLayoutFloatingOverlay
                navItems={navItems}
                brandName="Webild"
                button={{ text: "Get Started", onClick: () => console.log("Nav button clicked") }}
            />
            <FeatureCardOne
                title="Our Features"
                description="Discover what makes us different"
                gridVariant="uniform-all-items-equal"
                textboxLayout="split"
                features={features}
                carouselMode="buttons"
            
                animationType="slide-up"
            />
            </ReactLenis>
        </ThemeProvider>
    );
}
