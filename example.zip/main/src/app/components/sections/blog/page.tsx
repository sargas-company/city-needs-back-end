import ReactLenis from "lenis/react";
import Link from "next/link";

export default function BlogPage() {
    const blogComponents = [
        {
            title: "Blog Card One",
            href: "/components/sections/blog/card-one",
        },
        {
            title: "Blog Card Two",
            href: "/components/sections/blog/card-two",
        },
    ];

    return (
        <ReactLenis root>
            <section className="min-h-screen py-[var(--width-10)]">
                <div className="w-full px-[var(--width-10)]">
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                        {blogComponents.map((component) => (
                            <Link key={component.href} href={component.href}>
                                <div className="aspect-square tag-card relative rounded p-6 flex justify-center items-center text-center cursor-pointer">
                                    <h3 className="text-xl font-normal text-black">{component.title}</h3>
                                </div>
                            </Link>
                        ))}
                    </div>
                </div>
            </section>
        </ReactLenis>
    );
}
