"use client";

import ReactLenis from "lenis/react";
import BlogCardTwo from "@/components/sections/blog/BlogCardTwo";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function BlogCardTwoPage() {
    const blogs = [
        {
            id: "1",
            tags: ["Design", "Research", "Presentation"],
            title: "UX review presentations",
            excerpt: "How do you create compelling presentations that wow your colleagues and impress your managers?",
            imageSrc: "/placeholders/placeholder3.avif",
            imageAlt: "Abstract design with purple and silver tones",
            authorName: "Olivia Rhye",
            date: "20 Jan 2025",
            onBlogClick: () => console.log("Blog 1 clicked"),
        },
        {
            id: "2",
            tags: ["Development", "Code"],
            title: "Building scalable applications",
            excerpt: "Learn the best practices for building applications that can handle millions of users.",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "Development workspace",
            authorName: "John Smith",
            date: "18 Jan 2025",
            onBlogClick: () => console.log("Blog 2 clicked"),
        },
        {
            id: "3",
            tags: ["Marketing", "Strategy"],
            title: "Content strategy essentials",
            excerpt: "Discover how to create a content strategy that drives engagement and conversions.",
            imageSrc: "/placeholders/placeholder3.avif",
            imageAlt: "Marketing strategy board",
            authorName: "Sarah Johnson",
            date: "15 Jan 2025",
            onBlogClick: () => console.log("Blog 3 clicked"),
        },
        {
            id: "4",
            tags: ["Product", "Management"],
            title: "Product management 101",
            excerpt: "Everything you need to know to become an effective product manager in 2025.",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "Product planning session",
            authorName: "Mike Davis",
            date: "12 Jan 2025",
            onBlogClick: () => console.log("Blog 4 clicked"),
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <BlogCardTwo
                    blogs={blogs}
                    title="Latest Articles"
                    description="Stay updated with our latest insights"
                textboxLayout="default"
                    carouselMode="buttons"
                
                animationType="slide-up"
            />
            </ReactLenis>
        </ThemeProvider>
    );
}
