"use client";

import ReactLenis from "lenis/react";
import BlogCardOne from "@/components/sections/blog/BlogCardOne";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function BlogCardOnePage() {
    const blogs = [
        {
            id: "1",
            category: "Design",
            title: "UX review presentations",
            excerpt: "How do you create compelling presentations that wow your colleagues and impress your managers?",
            imageSrc: "/placeholders/placeholder3.avif",
            imageAlt: "Abstract design with purple and silver tones",
            authorName: "Olivia Rhye",
            authorAvatar: "/placeholders/placeholder3.avif",
            date: "20 Jan 2025",
            onBlogClick: () => console.log("Blog 1 clicked"),
        },
        {
            id: "2",
            category: "Development",
            title: "Building scalable applications",
            excerpt: "Learn the best practices for building applications that can handle millions of users.",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "Development workspace",
            authorName: "John Smith",
            authorAvatar: "/placeholders/placeholder4.webp",
            date: "18 Jan 2025",
            onBlogClick: () => console.log("Blog 2 clicked"),
        },
        {
            id: "3",
            category: "Marketing",
            title: "Content strategy essentials",
            excerpt: "Discover how to create a content strategy that drives engagement and conversions.",
            imageSrc: "/placeholders/placeholder3.avif",
            imageAlt: "Marketing strategy board",
            authorName: "Sarah Johnson",
            authorAvatar: "/placeholders/placeholder3.avif",
            date: "15 Jan 2025",
            onBlogClick: () => console.log("Blog 3 clicked"),
        },
        {
            id: "4",
            category: "Product",
            title: "Product management 101",
            excerpt: "Everything you need to know to become an effective product manager in 2025.",
            imageSrc: "/placeholders/placeholder4.webp",
            imageAlt: "Product planning session",
            authorName: "Mike Davis",
            authorAvatar: "/placeholders/placeholder4.webp",
            date: "12 Jan 2025",
            onBlogClick: () => console.log("Blog 4 clicked"),
        },
        // {
        //     id: "5",
        //     category: "Technology",
        //     title: "AI trends to watch",
        //     excerpt: "The latest developments in artificial intelligence and what they mean for your business.",
        //     imageSrc: "/placeholders/placeholder3.avif",
        //     imageAlt: "AI technology visualization",
        //     authorName: "Emily Chen",
        //     authorAvatar: "/placeholders/placeholder3.avif",
        //     date: "10 Jan 2025",
        //     onBlogClick: () => console.log("Blog 5 clicked"),
        // },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <BlogCardOne
                    blogs={blogs}
                    title="Latest Articles"
                    description="Stay updated with our latest insights"
                textboxLayout="default"
                    carouselMode="buttons"
                
                animationType="slide-up"
            />
            </ReactLenis>
        </ThemeProvider>
    );
}
