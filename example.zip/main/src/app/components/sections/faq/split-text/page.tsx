"use client";

import ReactLenis from "lenis/react";
import FaqSplitText from "@/components/sections/faq/FaqSplitText";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function FaqSplitTextPage() {
    const faqs = [
        {
            id: "1",
            title: "How can I be part of Buenro?",
            content: "You can join Buenro by signing up on our platform. We welcome remote workers and entrepreneurs from around the world.",
        },
        {
            id: "2",
            title: "Can anyone join Buenro?",
            content: "Yes! Buenro is open to anyone who is a remote worker or entrepreneur looking to connect with like-minded individuals.",
        },
        {
            id: "3",
            title: "How long will I be on the waitlist for?",
            content: "Waitlist times vary depending on demand, but we typically process applications within 2-4 weeks.",
        },
        {
            id: "4",
            title: "Do I need to be a remote worker or entrepreneur?",
            content: "Yes, Buenro is specifically designed for remote workers and entrepreneurs to network and collaborate.",
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="rounded" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <FaqSplitText
                    faqs={faqs}
                    sideTitle="Frequently Asked Questions"
                    textPosition="left"
                />
            </ReactLenis>
        </ThemeProvider>
    );
}
