"use client";

import ReactLenis from "lenis/react";
import FaqBase from "@/components/sections/faq/FaqBase";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function FaqBasePage() {
    const faqs = [
        {
            id: "1",
            title: "What is your return policy?",
            content: "We offer a 30-day money-back guarantee on all our products. If you're not satisfied, you can return the item for a full refund.",
        },
        {
            id: "2",
            title: "How long does shipping take?",
            content: "Standard shipping typically takes 5-7 business days. Express shipping options are available at checkout for faster delivery.",
        },
        {
            id: "3",
            title: "Do you ship internationally?",
            content: "Yes, we ship to over 100 countries worldwide. Shipping costs and delivery times vary by location.",
        },
        {
            id: "4",
            title: "How can I track my order?",
            content: "Once your order ships, you'll receive a tracking number via email. You can use this to track your package in real-time.",
        },
        {
            id: "5",
            title: "What payment methods do you accept?",
            content: "We accept all major credit cards, PayPal, Apple Pay, and Google Pay for your convenience.",
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <FaqBase
                    faqs={faqs}
                    title="Frequently Asked Questions"
                    description="Find answers to common questions"
                    textboxLayout="default"
                    // animationType="instant"
                />
            </ReactLenis>
        </ThemeProvider>
    );
}
