"use client";
import ReactLenis from "lenis/react";
import FooterLogoEmphasis from "@/components/sections/footer/FooterLogoEmphasis";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function FooterLogoEmphasisPage() {
    const columns = [
        {
            items: [
                { label: "Features", href: "features" },
                { label: "Pricing", href: "pricing" },
                { label: "FAQ", href: "faq" },
            ],
        },
        {
            items: [
                { label: "About", href: "about" },
                { label: "Blog", href: "blog" },
                { label: "Careers", href: "careers" },
            ],
        },
        {
            items: [
                { label: "Documentation", href: "docs" },
                { label: "Support", href: "support" },
                { label: "Contact", href: "contact" },
            ],
        },
        {
            items: [
                { label: "Twitter", href: "twitter" },
                { label: "LinkedIn", href: "linkedin" },
                { label: "GitHub", href: "github" },
            ],
        },
        {
            items: [
                { label: "Privacy Policy", href: "privacy" },
                { label: "Terms of Service", href: "terms" },
                { label: "Cookie Policy", href: "cookies" },
            ],
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="rounded" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <div className="min-h-screen bg-background">
                    <div className="h-screen flex items-center justify-center">
                        <h1 className="text-6xl font-bold text-foreground">Scroll down to see the footer</h1>
                    </div>
                    <FooterLogoEmphasis columns={columns} />
                </div>
            </ReactLenis>
        </ThemeProvider>
    );
}
