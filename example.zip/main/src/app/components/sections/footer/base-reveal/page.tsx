"use client";
import ReactLenis from "lenis/react";
import FooterBaseReveal from "@/components/sections/footer/FooterBaseReveal";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function FooterBaseRevealPage() {
    const columns = [
        {
            title: "Product",
            items: [
                { label: "Features", href: "features" },
                { label: "Pricing", href: "pricing" },
                { label: "FAQ", href: "faq" },
            ],
        },
        {
            title: "Company",
            items: [
                { label: "About", href: "about" },
                { label: "Blog", href: "blog" },
                { label: "Careers", href: "careers" },
            ],
        },
        {
            title: "Resources",
            items: [
                { label: "Documentation", href: "docs" },
                { label: "Support", href: "support" },
                { label: "Contact", href: "contact" },
            ],
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="rounded" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <div className="bg-background">
                    <div className="h-[200vh]">
                        <div className="h-screen flex items-center justify-center">
                            <h1 className="text-6xl font-bold text-foreground">Scroll down to reveal the footer</h1>
                        </div>
                        <div className="h-screen flex items-center justify-center">
                            <p className="text-2xl text-foreground">Footer will be revealed as you scroll</p>
                        </div>
                    </div>
                    <FooterBaseReveal
                        columns={columns}
                        copyrightText="© 2025 | Webild"
                        onPrivacyClick={() => console.log("Privacy clicked")}
                    />
                </div>
            </ReactLenis>
        </ThemeProvider>
    );
}
