import ReactLenis from "lenis/react";
import Link from "next/link";

export default function FooterPage() {
    const footerComponents = [
        {
            title: "Footer Base",
            href: "/components/sections/footer/base",
        },
        {
            title: "Footer Base Reveal",
            href: "/components/sections/footer/base-reveal",
        },
        {
            title: "Footer Logo Emphasis",
            href: "/components/sections/footer/logo-emphasis",
        },
        {
            title: "Footer Social",
            href: "/components/sections/footer/social",
        },
    ];

    return (
        <ReactLenis root>
            <section className="min-h-screen py-[var(--width-10)]">
                <div className="w-full px-[var(--width-10)]">
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                        {footerComponents.map((component) => (
                            <Link key={component.href} href={component.href}>
                                <div className="aspect-square tag-card relative rounded p-6 flex justify-center items-center text-center cursor-pointer">
                                    <h3 className="text-xl font-normal text-foreground">{component.title}</h3>
                                </div>
                            </Link>
                        ))}
                    </div>
                </div>
            </section>
        </ReactLenis>
    );
}
