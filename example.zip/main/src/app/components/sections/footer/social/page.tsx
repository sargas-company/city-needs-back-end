"use client";

import ReactLenis from "lenis/react";
import FooterSocial from "@/components/sections/footer/FooterSocial";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Instagram, Twitter, Youtube, Facebook } from "lucide-react";

export default function FooterSocialPage() {
    const columns = [
        {
            title: "Company",
            items: [
                { label: "About us", href: "about" },
                { label: "Careers", href: "careers" },
                { label: "Blog", href: "blog" },
            ],
        },
        {
            title: "Product",
            items: [
                { label: "Download App", href: "download" },
                { label: "Getting started", href: "getting-started" },
                { label: "Release notes", href: "releases" },
                { label: "Roadmap", href: "roadmap" },
                { label: "Beta", href: "beta" },
            ],
        },
        {
            title: "Resources",
            items: [
                { label: "FAQ", href: "faq" },
                { label: "Request a feature", href: "request-feature" },
                { label: "Report a bug", href: "report-bug" },
                { label: "Contact us", href: "contact" },
            ],
        },
        {
            title: "Legal",
            items: [
                { label: "Terms of Service", href: "terms" },
                { label: "Privacy Policy", href: "privacy" },
            ],
        },
    ];

    const socialLinks = [
        {
            icon: Instagram,
            href: "https://instagram.com",
            ariaLabel: "Instagram",
        },
        {
            icon: Twitter,
            href: "https://twitter.com",
            ariaLabel: "Twitter",
        },
        {
            icon: Youtube,
            href: "https://youtube.com",
            ariaLabel: "YouTube",
        },
        {
            icon: Facebook,
            href: "https://facebook.com",
            ariaLabel: "Facebook",
        },
    ];

    return (
        <ThemeProvider
            defaultButtonVariant="text-stagger"
            defaultTextAnimation="entrance-slide"
            borderRadius="rounded"
            contentWidth="medium"
            sizing="medium"
            background="aurora"
            cardStyle="glass-elevated"
            primaryButtonStyle="gradient"
            secondaryButtonStyle="glass"
        >
            <ReactLenis root>
                <div className="min-h-screen bg-background">
                    <div className="h-screen flex items-center justify-center">
                        <h1 className="text-6xl font-bold text-foreground">Scroll down to see the footer</h1>
                    </div>
                    <FooterSocial
                        logoText="Bevel"
                        columns={columns}
                        socialLinks={socialLinks}
                        copyrightText="© Finerpoint, Inc. 2025"
                    />
                </div>
            </ReactLenis>
        </ThemeProvider>
    );
}
