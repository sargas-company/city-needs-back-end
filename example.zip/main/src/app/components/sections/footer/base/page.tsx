"use client";
import ReactLenis from "lenis/react";
import FooterBase from "@/components/sections/footer/FooterBase";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function FooterBasePage() {
    const columns = [
        {
            title: "Product",
            items: [
                { label: "Features", href: "features" },
                { label: "Pricing", href: "pricing" },
                { label: "FAQ", href: "faq" },
            ],
        },
        {
            title: "Company",
            items: [
                { label: "About", href: "about" },
                { label: "Blog", href: "blog" },
                { label: "Careers", href: "careers" },
            ],
        },
        {
            title: "Resources",
            items: [
                { label: "Documentation", href: "docs" },
                { label: "Support", href: "support" },
                { label: "Contact", href: "contact" },
            ],
        },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="rounded" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <div className="min-h-screen bg-background">
                    <div className="h-screen flex items-center justify-center">
                        <h1 className="text-6xl font-bold text-foreground">Scroll down to see the footer</h1>
                    </div>
                    <FooterBase
                        columns={columns}
                        copyrightText="© 2025 | Webild"
                        onPrivacyClick={() => console.log("Privacy clicked")}
                    />
                </div>
            </ReactLenis>
        </ThemeProvider>
    );
}
