"use client";

import ReactLenis from "lenis/react";
import AboutPhoneTimeline from "@/components/sections/about/AboutPhoneTimeline";
import NavbarLayoutFloatingOverlay from "@/components/navbar/NavbarLayoutFloatingOverlay/NavbarLayoutFloatingOverlay";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function AboutPhoneTimelinePage() {
    const navItems = [
        { name: "Home", id: "home" },
        { name: "About", id: "about" },
        { name: "Services", id: "services" },
        { name: "Contact", id: "contact" },
    ];

    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="layered-gradient" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <NavbarLayoutFloatingOverlay
                    navItems={navItems}
                    brandName="Webild"
                    button={{ text: "Get Started", onClick: () => console.log("Nav button clicked") }}
                />
                <section className="relative w-full h-screen flex items-center justify-center" >
                    <p className="text-4xl text-foreground" >scroll</p>
                </section>
                <AboutPhoneTimeline
                    tag="About Us"
                    title="Our Mission"
                    description="We believe in creating experiences that inspire, empower, and transform. Our team is dedicated to building solutions that make a real difference in people's lives."
                    phoneOne={{
                        imageSrc: "/placeholders/placeholder2.jpg",
                    }}
                    phoneTwo={{
                        imageSrc: "/placeholders/placeholder2.jpg",
                    }}
                />
            </ReactLenis>
        </ThemeProvider>
    );
}
