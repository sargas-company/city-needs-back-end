"use client";
import ReactLenis from "lenis/react";
import SplitAboutMetric from "@/components/sections/about/SplitAboutMetric";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function SplitAboutMetricPage() {
    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="rounded" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <section className="h-screen" ></section>
                <SplitAboutMetric
                    title="About"
                    description={[
                        "My mission is to bring Olympic-level excellence to athletes everywhere - just like the pursuit of gold on the world stage. After years of dedication, discipline, and victory, I'm now sharing my passion with the next generation."
                    ]}
                    metrics={[
                        {
                            label: "Various types of landmarks built",
                            value: "75+"
                        },
                        {
                            label: "Sq.ft area",
                            value: "15M+"
                        }
                    ]}
                />
                <section className="h-screen" ></section>
            </ReactLenis>
        </ThemeProvider>
    );
}
