"use client";
import ReactLenis from "lenis/react";
import AboutMetric from "@/components/sections/about/AboutMetric";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { TrendingUp, ShoppingCart, Users, Globe } from "lucide-react";

export default function AboutMetricPage() {
    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="rounded" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <section className="h-screen" ></section>
                <AboutMetric
                    title="At Berco Inc. we redefine innovation by empowering businesses to reach their full potential. From transformative eCommerce strategies to cutting-edge SaaS solutions, we're your partner in growth."
                    metrics={[
                        {
                            icon: TrendingUp,
                            label: "Conversions",
                            value: "7,000+"
                        },
                        {
                            icon: ShoppingCart,
                            label: "Ecommerce Since",
                            value: "2018"
                        },
                        {
                            icon: Users,
                            label: "Partnered Brands",
                            value: "30+"
                        },
                        {
                            icon: Globe,
                            label: "Global Impressions Generated Annually",
                            value: "100M+"
                        }
                    ]}
                />
                <section className="h-screen" ></section>
            </ReactLenis>
        </ThemeProvider>
    );
}
