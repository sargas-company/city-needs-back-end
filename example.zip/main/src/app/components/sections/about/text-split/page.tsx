"use client";
import ReactLenis from "lenis/react";
import TextSplitAbout from "@/components/sections/about/TextSplitAbout";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function TextSplitAboutPage() {
    return (
        <ThemeProvider defaultButtonVariant="icon-arrow" defaultTextAnimation="entrance-slide" borderRadius="rounded" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <TextSplitAbout
                    title="About"
                    description={[
                        "My mission is to bring Olympic-level excellence to athletes everywhere - just like the pursuit of gold on the world stage. After years of dedication, discipline, and victory, I'm now sharing my passion with the next generation.",
                        "I work with driven athletes who want to push beyond limits. Because for me, training isn't just about performance. It's about winning, achieving, and believing in the potential that lies within you."
                    ]}
                    showBorder={true}
                    buttons={[
                        {
                            text: "Get Started",
                            onClick: () => console.log("Get Started clicked")
                        },
                        {
                            text: "Learn More",
                            onClick: () => console.log("Learn More clicked")
                        }
                    ]}
                />
            </ReactLenis>
        </ThemeProvider>
    );
}
