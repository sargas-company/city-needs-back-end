"use client";
import ReactLenis from "lenis/react";
import AboutFeature from "@/components/sections/about/AboutFeature";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Rocket, Users, Target, Sparkles } from "lucide-react";

export default function AboutFeaturePage() {
    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="rounded" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <section className="h-screen" ></section>
                <AboutFeature
                    title="We believe in creating experiences that inspire, empower, and transform. Our team is dedicated to building solutions that make a real difference."
                    features={[
                        {
                            icon: Rocket,
                            title: "Innovation First",
                            description: "We push boundaries and embrace cutting-edge technologies to deliver exceptional results that exceed expectations.",
                        },
                        {
                            icon: Users,
                            title: "Team Collaboration",
                            description: "Our diverse team works together seamlessly to bring your vision to life with expertise and dedication.",
                        },
                        {
                            icon: Target,
                            title: "Goal Oriented",
                            description: "We focus on measurable outcomes and strategic objectives to ensure your success and growth.",
                        },
                        {
                            icon: Sparkles,
                            title: "Quality Driven",
                            description: "Every detail matters. We maintain the highest standards in everything we create and deliver.",
                        }
                    ]}
                />
                <section className="h-screen" ></section>
            </ReactLenis>
        </ThemeProvider>
    );
}
