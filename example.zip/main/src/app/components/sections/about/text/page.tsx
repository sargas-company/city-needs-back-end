"use client";
import ReactLenis from "lenis/react";
import TextAbout from "@/components/sections/about/TextAbout";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function TextAboutPage() {
    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="rounded" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <section className="h-screen" ></section>
                <TextAbout
                    title="We believe in creating experiences that inspire, empower, and transform. Our team is dedicated to building solutions that make a real difference in people's lives."
                    buttons={[
                        {
                            text: "Join Us",
                            onClick: () => console.log("Join Us clicked")
                        },
                        {
                            text: "Our Story",
                            onClick: () => console.log("Our Story clicked")
                        }
                    ]}
                />
                <section className="h-screen" ></section>
            </ReactLenis>
        </ThemeProvider>
    );
}
