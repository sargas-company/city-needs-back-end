"use client";
import ReactLenis from "lenis/react";
import TagAbout from "@/components/sections/about/TagAbout";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";

export default function TagAboutPage() {
    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="rounded" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <section className="h-screen" ></section>
                <TagAbout
                    tag="Why us"
                    description="At DialedWeb, we embody the startup mindset — dynamic, innovative, and hungry to make a difference. We don't just create amazing works; we partner with our clients to revolutionize their industries through groundbreaking digital experiences. From redefining brand engagement to boosting conversions, every project we take on is an opportunity to challenge the norm, deliver excellence, and leave an impact."
                />
                <section className="h-screen" ></section>
            </ReactLenis>
        </ThemeProvider>
    );
}
