"use client";
import ReactLenis from "lenis/react";
import SplitAbout from "@/components/sections/about/SplitAbout";
import { ThemeProvider } from "@/providers/themeProvider/ThemeProvider";
import { Sparkles, Target, Zap } from "lucide-react";

export default function SplitAboutPage() {
    return (
        <ThemeProvider defaultButtonVariant="text-stagger" defaultTextAnimation="entrance-slide" borderRadius="pill" contentWidth="medium" sizing="medium" background="aurora" cardStyle="glass-elevated" primaryButtonStyle="gradient" secondaryButtonStyle="glass">
            <ReactLenis root>
                <SplitAbout
                    title="About Us"
                    description="Learn more about our mission, values, and what drives us forward"
                textboxLayout="default"
                    bulletPoints={[
                        {
                            title: "Innovation First",
                            description: "We push the boundaries of what's possible, constantly exploring new technologies and methodologies to deliver cutting-edge solutions.",
                            icon: Sparkles
                        },
                        {
                            title: "Mission Driven",
                            description: "Our goal is to empower businesses with tools that transform their digital presence and drive measurable results.",
                            icon: Target
                        },
                        {
                            title: "Performance Focused",
                            description: "Every solution we build is optimized for speed, efficiency, and scalability to ensure your success.",
                            icon: Zap
                        },
                        {
                            title: "Mission Driven",
                            description: "Our goal is to empower businesses with tools that transform their digital presence and drive measurable results.",
                            icon: Target
                        }
                    ]}
                    imageSrc="/placeholders/placeholder2.jpg"
                    imageAlt="About us"
                    imagePosition="right"
                />
            </ReactLenis>
        </ThemeProvider>
    );
}
