export type AnimationType = "entrance-slide" | "reveal-blur" | "background-highlight";
